/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.inimigo;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.movimento.MovimentoGenerico;
import jogos.spaceship.movimento.MovimentoCoronaAvanca;
import jogos.spaceship.movimento.MovimentoCoronaPersegue;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class InimigoCoronaTeste {
    
    @Test
    public void deveCaminharParaAEsquerda(){
    //cenário                
        ChipGrafico chipGrafico = new ChipGrafico();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,new ChipSom());        
        int passo_corona = 6;
        int ciclos = 100;
        MovimentoGenerico movimento = new MovimentoCoronaAvanca(passo_corona, chipGrafico);
        InimigoGenerico corona = new InimigoCorona(nave, movimento,chipGrafico);     
    //ação 
        for(int i = 1; i<= ciclos; i++){
            corona.seMovimenta();
        }    
    //verificação
        assertThat(corona.getX(), equalTo(chipGrafico.getLargura_imagem_fundo()-ciclos*passo_corona));    
    }

    @Test
    public void devePerseguirANave(){
    //cenário            
        ChipGrafico chipGrafico = new ChipGrafico();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,new ChipSom());
        nave.setPasso(1);
        int passo_corona = 1;
        int ciclos = 1024;
        MovimentoGenerico movimento = new MovimentoCoronaPersegue(passo_corona, nave, chipGrafico);
        InimigoGenerico corona = new InimigoCorona(nave, movimento,chipGrafico);     
    //ação      
        for(int i = 1; i<= ciclos; i++){
            corona.seMovimenta();
        } 
    //verificação
        assertThat(corona.getX(), equalTo(corona.getX())); 
        assertThat(corona.getX(), equalTo(movimento.getX()));
    }    
}
