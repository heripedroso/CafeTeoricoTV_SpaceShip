/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.inimigo;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.movimento.MovimentoCoronaPersegue;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class OndaCoronasTeste {
    @Test
    public void deveGerarApenas01Corona(){
    //cenário                
        NaveEspacialGenerica nave = new NaveEspacialRaptor(new ChipGrafico(),new ChipSom());
        int passo_corona = 6;
        OndaCoronas onda = new OndaCoronas(1, 100, passo_corona, nave, new ChipGrafico(), new MovimentoCoronaPersegue(passo_corona,nave,new ChipGrafico()));
    //ação               
         for(int i = 1; i <= 300; i++){
             onda.geraCorona();
         }
    //verificação
        assertThat(onda.getCoronas().size(),equalTo(1));  
    }

    @Test
    public void deveGerarApenas02Coronas(){
    //cenário                
        NaveEspacialGenerica nave = new NaveEspacialRaptor(new ChipGrafico(),new ChipSom());
        int passo_corona = 6;
        OndaCoronas onda = new OndaCoronas(2, 100, passo_corona, nave, new ChipGrafico(), new MovimentoCoronaPersegue(passo_corona,nave,new ChipGrafico()));
    //ação               
         for(int i = 1; i <= 300; i++){
             onda.geraCorona();
         }
    //verificação 
        assertThat(onda.getCoronas().size(),equalTo(2));  
    }
    
    @Test
    public void deveCoronaGeradoPerseguirANave(){
    //cenário            
        NaveEspacialGenerica nave = new NaveEspacialRaptor(new ChipGrafico(),new ChipSom());
        nave.setPasso(1);
        int passo_corona = 1;
        int ciclos = 1024;
        ChipGrafico chipGrafico = new ChipGrafico();
        OndaCoronas onda = new OndaCoronas(1, 100, passo_corona, nave, chipGrafico, new MovimentoCoronaPersegue(passo_corona,nave,chipGrafico));   
        for(int i = 1; i <= ciclos; i++){
             onda.geraCorona();
        }        
    //ação  
        for(int i = 1; i <= ciclos; i++){            
            onda.getCoronas().get(0).seMovimenta();
        }
    //verificação
        assertThat(onda.getCoronas().get(0).getX(), equalTo(nave.getX()));
        assertThat(onda.getCoronas().get(0).getY(), equalTo(nave.getY()));
    }       
}
