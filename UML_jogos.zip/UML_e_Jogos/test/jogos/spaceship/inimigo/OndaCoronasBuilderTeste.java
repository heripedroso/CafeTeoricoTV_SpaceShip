/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.inimigo;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class OndaCoronasBuilderTeste {
    
    @Test
    public void deveGerarApenas01Corona(){
    //cenário                
        int passo_corona = 1;
        int ciclos = 1024;
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);   
        nave.setPasso(1);
        OndaCoronasBuilder ondaBuilder = new OndaCoronasBuilder();  
        OndaCoronas onda = ondaBuilder
                                .atributo01_conectaChipGrafico(chipGrafico)
                                .atributo02_setNaveInimiga(nave)
                                .atributo03_seQtdeCoronas(1)
                                .atributo04_setPassoCoronas(passo_corona)
                                .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                .atributo06_setMovimentoCoronaPersegueNave()
                                .produz();   
    //ação               
         for(int i = 1; i <= ciclos; i++){
             onda.geraCorona();
         }
    //verificação
        assertThat(onda.getCoronas().size(),equalTo(1));  
    }

    @Test
    public void deveGerarApenas02Coronas(){
    //cenário                
        int passo_corona = 2;
        int ciclos = 300;
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);        
        OndaCoronasBuilder ondaBuilder = new OndaCoronasBuilder();  
        OndaCoronas onda = ondaBuilder
                                .atributo01_conectaChipGrafico(chipGrafico)
                                .atributo02_setNaveInimiga(nave)
                                .atributo03_seQtdeCoronas(2)
                                .atributo04_setPassoCoronas(passo_corona)
                                .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                .atributo06_setMovimentoCoronaPersegueNave()
                                .produz();    
    //ação               
         for(int i = 1; i <= ciclos; i++){
             onda.geraCorona();
         }
    //verificação 
        assertThat(onda.getCoronas().size(),equalTo(2));  
    }
    
    @Test
    public void deveCoronaGeradoAvancar(){
    //cenário                
        int passo_corona = 2;
        int ciclos = 300;
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);        
        OndaCoronasBuilder ondaBuilder = new OndaCoronasBuilder();  
        OndaCoronas onda = ondaBuilder
                                .atributo01_conectaChipGrafico(chipGrafico)
                                .atributo02_setNaveInimiga(nave)
                                .atributo03_seQtdeCoronas(1)
                                .atributo04_setPassoCoronas(passo_corona)
                                .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                .atributo06_setMovimentoCoronaAvanca()
                                .produz();     
        for(int i = 1; i <= ciclos; i++){
             onda.geraCorona();
        }        
    //ação  
        for(int i = 1; i <= ciclos; i++){            
            onda.getCoronas().get(0).seMovimenta();
        }
    //verificação
        assertThat(onda.getCoronas().get(0).getX(), equalTo(chipGrafico.getLargura_imagem_fundo() - passo_corona*ciclos));
    }           

    @Test
    public void deveCoronaGeradoPerseguirNave(){
    //cenário                
        int passo_corona = 1;
        int ciclos = 1024;
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);
        nave.setPasso(1);
        OndaCoronasBuilder ondaBuilder = new OndaCoronasBuilder();  
        OndaCoronas onda = ondaBuilder
                                .atributo01_conectaChipGrafico(chipGrafico)
                                .atributo02_setNaveInimiga(nave)
                                .atributo03_seQtdeCoronas(1)
                                .atributo04_setPassoCoronas(passo_corona)
                                .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                .atributo06_setMovimentoCoronaPersegueNave()
                                .produz();    
        for(int i = 1; i <= ciclos; i++){
             onda.geraCorona();
        }        
    //ação  
        for(int i = 1; i <= ciclos; i++){            
            onda.getCoronas().get(0).seMovimenta();
        }
    //verificação
        assertThat(onda.getCoronas().get(0).getX(), equalTo(nave.getX()));
        assertThat(onda.getCoronas().get(0).getY(), equalTo(nave.getY()));
    }   
}
