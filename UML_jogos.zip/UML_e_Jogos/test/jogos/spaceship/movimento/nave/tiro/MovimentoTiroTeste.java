/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.movimento.nave.tiro;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.movimento.MovimentoGenerico;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static junit.framework.Assert.assertTrue;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class MovimentoTiroTeste {
    
    @Test
    public void deveSeMovimentarParaADireita() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();      
        MovimentoGenerico movimento = new MovimentoTiroSimples(100,100,10,chipGrafico);
    //ação
        movimento.movimenta();
    //verificação
        assertThat(movimento.getX(), equalTo(110));       
    }        

}
