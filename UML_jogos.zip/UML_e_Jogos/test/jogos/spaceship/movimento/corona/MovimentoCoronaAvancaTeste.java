/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.movimento.corona;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.movimento.MovimentoGenerico;
import jogos.spaceship.movimento.nave.tiro.MovimentoTiroSimples;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class MovimentoCoronaAvancaTeste {
    @Test
    public void deveSeMovimentarParaEsquerda() throws Exception{
    //cenário 
        int passo = 25;
        ChipGrafico chipGrafico = new ChipGrafico();      
        MovimentoGenerico movimento = new MovimentoCoronaAvanca(passo,chipGrafico);
    //ação
        movimento.movimenta();
    //verificação
        assertThat(movimento.getX(), equalTo(1024-passo));       
    }        
    
}
