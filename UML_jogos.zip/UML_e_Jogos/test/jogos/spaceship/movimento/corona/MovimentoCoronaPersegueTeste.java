/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.movimento.corona;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.movimento.MovimentoGenerico;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class MovimentoCoronaPersegueTeste {
    @Test
    public void devePerseguirANave() throws Exception{
    //cenário 
        int ciclos = 1024;
        int passo = 1;
        ChipGrafico chipGrafico = new ChipGrafico();     
        ChipSom chipSom = new ChipSom();                                                                
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);         
        MovimentoGenerico movimento = new MovimentoCoronaPersegue(passo,nave,chipGrafico);
    //ação
        for(int i = 1; i <= ciclos; i++){            
            movimento.movimenta();
        }
    //verificação
        assertThat(movimento.getX(), equalTo(nave.getX()));      
        assertThat(movimento.getY(), equalTo(nave.getY())); 
    }            
}
