/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship;

import console.Processador;
import console.Som;
import console.SuperNintendo;
import console.Tela;
import console.controles.ControleGenerico;
import console.controles.ControleTecladoDireito;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static junit.framework.Assert.assertTrue;
import org.junit.Test;


/**
 *
 * @author Heriberto
 */
public class JogoTeste {
    
    @Test
    public void deveConectarTelaAtravesSnes() throws Exception{
    //cenário        
        SuperNintendo snes = new SuperNintendo();             
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);                                                     
    //ação
        snes.conectaJogo(spaceShip);      
    //verificação
        assertTrue(spaceShip.isTelaConectada());    
    }

    @Test
    public void deveConectarPincelAtravesSnes() throws Exception{
    //cenário        
        Tela tela = new Tela();
        Som som = new Som();      
        SuperNintendo snes = new SuperNintendo();     
        Processador processador = new Processador(tela, som, snes);    
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);  
        ControleGenerico controle = new ControleTecladoDireito(); 
        
        snes.setProcessador(processador);        
        
        snes.conectaJogo(spaceShip);
        snes.conectaControle(controle);
        
        snes.add(tela);
        snes.setVisible(true);        
    //ação
        snes.conectaPincel(tela.getGraphics());
    //verificação 
        assertTrue(spaceShip.isPincelConectado());           
    }    
    
    @Test
    public void deveReceberComandoStart(){
    //cenário                 
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);                                                     
    //ação
        spaceShip.recebeComando("Controle 01: start");
    //verificação
        assertTrue(spaceShip.startPressionado());    
    }        

    @Test
    public void deveIrParaEstadoIniciado(){
    //cenário                 
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);  
        spaceShip.recebeComando("Controle 01: start");
    //ação
        spaceShip.alternaEstados();
    //verificação
        assertTrue(spaceShip.isIniciado());    
    }    

    @Test
    public void deveIrParaEstadoPausado(){
    //cenário                 
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);  
        spaceShip.vaiParaEstadoIniciado();
        spaceShip.recebeComando("Controle 01: start");
    //ação
        spaceShip.alternaEstados();
    //verificação
        assertTrue(spaceShip.isPausado());    
    }      
    
    @Test
    public void deveIrDoEstadoPausadoParaEstadoIniciado(){
    //cenário                 
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);  
        spaceShip.vaiParaEstadoPausado();
        spaceShip.recebeComando("Controle 01: start");
    //ação
        spaceShip.alternaEstados();
    //verificação
        assertTrue(spaceShip.isIniciado());    
    }  

    @Test
    public void deveIrParaEstadoGameOver(){
    //cenário                 
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);  
        nave.setAbatida(true);
    //ação
        spaceShip.alternaEstados();
    //verificação
        assertTrue(spaceShip.isGameOver());    
    }  

    @Test
    public void deveIrDoEstadoGameOverParaEstadoAguardandoStart(){
    //cenário                 
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);   
        spaceShip.vaiParaEstadoGameOver();
        spaceShip.recebeComando("start");
    //ação
        spaceShip.alternaEstados();
    //verificação
        assertTrue(spaceShip.isAguardandoStart());    
    }  
}
