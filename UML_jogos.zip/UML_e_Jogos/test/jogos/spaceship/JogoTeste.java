/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship;

import jogos.spaceship.estados.Estado;
import jogos.spaceship.estados.EstadoPressioneStartParaComecar;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.fase.FaseBuilder;
import jogos.spaceship.fase.FaseGenerica;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import org.junit.Test;


/**
 *
 * @author Heriberto
 */
public class JogoTeste {
    
    private Jogo jogo;    

    @Test
    public void deveIrDoEstadoAguardandoStart(){
    //cenário                 
        FaseBuilder faseBuilder;
        Estado estado;           
        
        faseBuilder = new FaseBuilder();
        
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        this.jogo = new Jogo(nave,chipGrafico,chipSom);      
        
        FaseGenerica primeira_fase = faseBuilder
                                        .atributo01_insereNave(nave)
                                        .atributo02_setPassoNave(6)
                                        .atributo03_setQtdeCoronas(10)
                                        .atributo04_setPassoCoronas(6) //Corona passa direto e não atinge a nave.
                                        .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                        .atributo06_insereChipGrafico(chipGrafico)
                                        .atributo07_insereChipGrafico(chipSom)
                                        .atributo08_setMovimentoCoronasAvancam()
                                        .produz();
        jogo.addFase(primeira_fase);
    //Ação
        jogo.vaiParaEstado(new EstadoPressioneStartParaComecar(jogo, primeira_fase, chipGrafico, chipSom));
    //verificação
        assertThat(jogo.isAguardandoStart(),equalTo(true));     
    }  
    
    @Test
    public void deveReceberComandoStart(){
    //cenário                 
        FaseBuilder faseBuilder;
        Estado estado;           
        
        faseBuilder = new FaseBuilder();
        
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        this.jogo = new Jogo(nave,chipGrafico,chipSom);      
        
        FaseGenerica primeira_fase = faseBuilder
                                        .atributo01_insereNave(nave)
                                        .atributo02_setPassoNave(6)
                                        .atributo03_setQtdeCoronas(5)
                                        .atributo04_setPassoCoronas(4)
                                        .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                        .atributo06_insereChipGrafico(chipGrafico)
                                        .atributo07_insereChipGrafico(chipSom)
                                        .atributo08_setMovimentoCoronasAvancam()
                                        .produz();
        jogo.addFase(primeira_fase);

        jogo.vaiParaEstado(new EstadoPressioneStartParaComecar(jogo, primeira_fase, chipGrafico, chipSom));                                                     
    //ação
        jogo.executaCiclo();
        jogo.recebeComando("Controle 01: start");
        jogo.executaCiclo();
    //verificação
        assertThat(jogo.isAguardandoStart(),equalTo(false));
        //assertThat(jogo.startPressionado(),equalTo(true));    
        //assertThat(jogo.isExecutandoFase(),equalTo(true));
        
    }        

    @Test
    public void deveIrParaExecutandoFase(){
    //cenário                 
        FaseBuilder faseBuilder;
        Estado estado;           
        
        faseBuilder = new FaseBuilder();
        
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        this.jogo = new Jogo(nave,chipGrafico,chipSom);      
        
        FaseGenerica primeira_fase = faseBuilder
                                        .atributo01_insereNave(nave)
                                        .atributo02_setPassoNave(6)
                                        .atributo03_setQtdeCoronas(5)
                                        .atributo04_setPassoCoronas(4)
                                        .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                        .atributo06_insereChipGrafico(chipGrafico)
                                        .atributo07_insereChipGrafico(chipSom)
                                        .atributo08_setMovimentoCoronasAvancam()
                                        .produz();
        jogo.addFase(primeira_fase);

        jogo.vaiParaEstado(new EstadoPressioneStartParaComecar(jogo, primeira_fase, chipGrafico, chipSom));
    //ação
        jogo.recebeComando("Controle 01: start");
        jogo.executaCiclo();
    //verificação  
        assertThat(jogo.isExecutandoFase(),equalTo(true));
    }    

    @Test
    public void deveIrParaEstadoFasePausada(){
    //cenário                 
    //cenário                 
        FaseBuilder faseBuilder;
        Estado estado;           
        
        faseBuilder = new FaseBuilder();
        
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        this.jogo = new Jogo(nave,chipGrafico,chipSom);      
        
        FaseGenerica primeira_fase = faseBuilder
                                        .atributo01_insereNave(nave)
                                        .atributo02_setPassoNave(6)
                                        .atributo03_setQtdeCoronas(5)
                                        .atributo04_setPassoCoronas(4)
                                        .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                        .atributo06_insereChipGrafico(chipGrafico)
                                        .atributo07_insereChipGrafico(chipSom)
                                        .atributo08_setMovimentoCoronasAvancam()
                                        .produz();
        jogo.addFase(primeira_fase);

        jogo.vaiParaEstado(new EstadoPressioneStartParaComecar(jogo, primeira_fase, chipGrafico, chipSom));
    //ação
        jogo.recebeComando("Controle 01: start");
        jogo.executaCiclo();
        jogo.recebeComando("Controle 01: start");
        jogo.executaCiclo();
    //verificação  
        assertThat(jogo.isFasePausada(),equalTo(true)); 
    }      
    
    @Test
    public void deveIrDoEstadoFaseFinalizada(){              
    //cenário                 
        FaseBuilder faseBuilder;
        Estado estado;           
        
        faseBuilder = new FaseBuilder();
        
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        this.jogo = new Jogo(nave,chipGrafico,chipSom);      
        
        FaseGenerica primeira_fase = faseBuilder
                                        .atributo01_insereNave(nave)
                                        .atributo02_setPassoNave(6)
                                        .atributo03_setQtdeCoronas(1)
                                        .atributo04_setPassoCoronas(1024) //Corona passa direto e não atinge a nave.
                                        .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                        .atributo06_insereChipGrafico(chipGrafico)
                                        .atributo07_insereChipGrafico(chipSom)
                                        .atributo08_setMovimentoCoronasAvancam()
                                        .produz();
        jogo.addFase(primeira_fase);

        jogo.vaiParaEstado(new EstadoPressioneStartParaComecar(jogo, primeira_fase, chipGrafico, chipSom));
    //ação
        jogo.recebeComando("Controle 01: start");
        jogo.executaCiclo();
        jogo.executaCiclo();
        jogo.executaCiclo();        
        jogo.executaCiclo();
    //verificação  
        assertThat(jogo.isFaseFinalizada(),equalTo(true)); 
    }  

    @Test
    public void deveIrParaEstadoGameOver(){             
    //cenário                 
        FaseBuilder faseBuilder;
        Estado estado;           
        
        faseBuilder = new FaseBuilder();
        
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        this.jogo = new Jogo(nave,chipGrafico,chipSom);      
        
        FaseGenerica primeira_fase = faseBuilder
                                        .atributo01_insereNave(nave)
                                        .atributo02_setPassoNave(6)
                                        .atributo03_setQtdeCoronas(10)
                                        .atributo04_setPassoCoronas(6) //Corona passa direto e não atinge a nave.
                                        .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                        .atributo06_insereChipGrafico(chipGrafico)
                                        .atributo07_insereChipGrafico(chipSom)
                                        .atributo08_setMovimentoCoronasAvancam()
                                        .produz();
        jogo.addFase(primeira_fase);

        jogo.vaiParaEstado(new EstadoPressioneStartParaComecar(jogo, primeira_fase, chipGrafico, chipSom));
    //ação
        jogo.recebeComando("Controle 01: start");
        jogo.executaCiclo();
        nave.setAbatida(true);
        jogo.executaCiclo();
        jogo.executaCiclo();
        jogo.executaCiclo();
    //verificação
        assertThat(jogo.isGameOver(),equalTo(true));    
    }  

}
