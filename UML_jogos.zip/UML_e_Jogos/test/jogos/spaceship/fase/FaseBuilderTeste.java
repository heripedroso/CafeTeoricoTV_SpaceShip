/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.fase;

import console.controles.ControleGenerico;
import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.colisao.Colisao;
import jogos.spaceship.inimigo.OndaCoronas;
import jogos.spaceship.inimigo.OndaCoronasBuilder;
import jogos.spaceship.movimento.MovimentoGenerico;
import jogos.spaceship.movimento.MovimentoCoronaPersegue;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class FaseBuilderTeste {
        
    FaseBuilder faseBuilder = new FaseBuilder();
    
    @Test
    public void deveIniciarFase() throws Exception{
    //cenário                
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);
        int passo_corona = 2;
        int ciclos = 300;  
        FaseGenerica fase = faseBuilder
                                .atributo01_insereNave(nave)
                                .atributo02_setPassoNave(6)
                                .atributo03_setQtdeCoronas(1)
                                .atributo04_setPassoCoronas(passo_corona)
                                .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                .atributo06_insereChipGrafico(chipGrafico)
                                .atributo07_insereChipSom(chipSom)
                                .atributo08_setMovimentoCoronasAvancam()
                                .produz();
    //ação      
         fase.inicia();
    //verificação
        assertThat(fase.isIniciada(),equalTo(true));
    }

    @Test
    public void deveIniciarFase_01() throws Exception{
    //cenário                
        int passo_corona = 2;
        int ciclos = 300;
        int qtdeCoronas = 1;
        int qtdeCiclosCoronasGerados = 100;
    
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);       
        
        MovimentoGenerico movimento = new MovimentoCoronaPersegue(passo_corona,nave,chipGrafico);
        
        OndaCoronas onda = new OndaCoronas(qtdeCoronas, qtdeCiclosCoronasGerados, passo_corona, nave, chipGrafico, movimento);  
        
        FaseGenerica fase = new Fase(nave, onda, new Colisao(chipGrafico, chipSom), chipGrafico,chipSom);
        
    //ação      
         fase.inicia();
    //verificação
        assertThat(fase.isIniciada(),equalTo(true));
    }    
    
    @Test
    public void deveIrParaFinalizadoQuandoCoronasAcabarem() throws Exception{
    //cenário                
        int passo_corona = 2;
        int ciclos = 300;
        int qtdeCoronas = 1;
        int qtdeCiclosCoronasGerados = 100;
    
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);
                
        MovimentoGenerico movimento = new MovimentoCoronaPersegue(passo_corona,nave,chipGrafico);
        
        OndaCoronas onda = new OndaCoronas(qtdeCoronas, qtdeCiclosCoronasGerados, passo_corona, nave, chipGrafico, movimento);  
        
        FaseGenerica fase = new Fase(nave, onda, new Colisao(chipGrafico, chipSom), chipGrafico,chipSom);               
        
        fase.inicia();
        for(int i = 1; i <= ciclos; i++){
            onda.executaCiclo();
             fase.recebeComando(ControleGenerico.paraCima);
             fase.executaCiclo();
             //nave.recebeComando(ControleGenerico.paraCima);
             //nave.executaCiclo();
        } 
    //ação      
         onda.getCoronas().clear();
    //verificação
        assertThat(fase.isOndaCoronasDerrotada(),equalTo(true));
    }    
}
