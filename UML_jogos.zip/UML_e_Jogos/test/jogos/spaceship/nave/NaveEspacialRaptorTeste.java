/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave;

import console.controles.ControleGenerico;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import static junit.framework.Assert.assertTrue;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class NaveEspacialRaptorTeste {

    @Test
    public void deveIniciarNoPonto100x100() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();                                                                   
    //ação
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);  
    //verificação
        assertTrue(nave.getX() == 100 && nave.getY() == 100);       
    }    

    @Test
    public void deveIniciarAbatidaFalse() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();                                                                   
    //ação
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom);  
    //verificação
        assertTrue(nave.isAbatida() == false);       
    }   
    
    @Test
    public void deveSeMovimentarParaCima() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();  
        NaveEspacialRaptor nave = new NaveEspacialRaptor(chipGrafico,chipSom);
        nave.setPosicaoInicial(); //100x100
        nave.setPasso(6);
    //ação        
        nave.recebeComando(ControleGenerico.paraCima);
        nave.executaCiclo();
    //verificação
        assertTrue(nave.getY() == 94);       
    }  

    @Test
    public void deveSeMovimentarParaBaixo() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();  
        NaveEspacialRaptor nave = new NaveEspacialRaptor(chipGrafico,chipSom);
        nave.setPosicaoInicial(); //100x100
        nave.setPasso(6);
    //ação        
        nave.recebeComando(ControleGenerico.paraBaixo);
        nave.executaCiclo();
    //verificação
        assertTrue(nave.getY() == 106);       
    }
    
    @Test
    public void deveSeMovimentarParaEsquerda() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();  
        NaveEspacialRaptor nave = new NaveEspacialRaptor(chipGrafico,chipSom);
        nave.setPosicaoInicial(); //100x100
        nave.setPasso(6);
    //ação        
        nave.recebeComando(ControleGenerico.paraEsquerda);
        nave.executaCiclo();
    //verificação
        assertTrue(nave.getX() == 94);       
    } 

    @Test
    public void deveSeMovimentarParaDireita() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();  
        NaveEspacialRaptor nave = new NaveEspacialRaptor(chipGrafico,chipSom);
        nave.setPosicaoInicial(); //100x100
        nave.setPasso(6);
    //ação        
        nave.recebeComando(ControleGenerico.paraDireita);
        nave.executaCiclo();
    //verificação
        assertTrue(nave.getX() == 106);       
    } 

    @Test
    public void deveAtirarUmTiro() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();  
        NaveEspacialRaptor nave = new NaveEspacialRaptor(chipGrafico,chipSom);
        nave.setPosicaoInicial(); //100x100
        nave.setPasso(6);
    //ação        
        nave.recebeComando(ControleGenerico.botaoY);
        nave.executaCiclo();
        nave.recebeComando("");
        nave.executaCiclo();
        //verificação
        assertTrue(nave.getRajada_tiros().size() == 1);       
    } 
    
}
