/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave.canhao;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import jogos.spaceship.nave.canhao.tiro.TiroForte;
import jogos.spaceship.nave.canhao.tiro.TiroMedio;
import jogos.spaceship.nave.canhao.tiro.TiroSimples;
import static junit.framework.Assert.assertTrue;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class CanhaoTeste {

    
    @Test
    public void deveCarregarEnergia() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();                                                                   
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom); 
        CanhaoRaptor canhao = new CanhaoRaptor(nave,chipGrafico,chipSom);
    //ação       
        for (int i = 0; i < 50; i++) {
            canhao.carregaEnergia();
        }    
    //verificação
        assertTrue(canhao.getContador_energia() == 50);       
    }  

    @Test
    public void deveCarregarEnergiaAte75() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();                                                                   
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom); 
        CanhaoRaptor canhao = new CanhaoRaptor(nave,chipGrafico,chipSom);
    //ação       
        for (int i = 0; i < 90; i++) {
            canhao.carregaEnergia();
        }    
    //verificação
        assertTrue(canhao.getContador_energia() == 75);       
    }  
    
    @Test
    public void deveAtirarUmTiroSimples() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();                                                                   
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom); 
        CanhaoRaptor canhao = new CanhaoRaptor(nave,chipGrafico,chipSom);
        canhao.carregaEnergia();
    //ação
        canhao.atira();        
    //verificação
        assertTrue(canhao.getRajada_tiros().get(0).getClass() == TiroSimples.class);       
    }        

    @Test
    public void deveAtirarUmTiroMedio() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();                                                                   
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom); 
        CanhaoRaptor canhao = new CanhaoRaptor(nave,chipGrafico,chipSom);
        for (int i = 0; i < 38; i++) {
            canhao.carregaEnergia();
        }
    //ação
        canhao.atira();        
    //verificação
        assertTrue(canhao.getRajada_tiros().get(0).getClass() == TiroMedio.class);       
    }      

    @Test
    public void deveAtirarUmTiroForte() throws Exception{
    //cenário        
        ChipSom chipSom = new ChipSom();
        ChipGrafico chipGrafico = new ChipGrafico();                                                                   
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico,chipSom); 
        CanhaoRaptor canhao = new CanhaoRaptor(nave,chipGrafico,chipSom);
        for (int i = 0; i < 90; i++) {
            canhao.carregaEnergia();
        }
    //ação
        canhao.atira();        
    //verificação
        assertTrue(canhao.getRajada_tiros().get(0).getClass() == TiroForte.class);       
    }      

}
