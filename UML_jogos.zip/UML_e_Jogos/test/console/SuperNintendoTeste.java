/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console;

import console.controles.ControleGenerico;
import console.controles.ControleTecladoDireito;
import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static junit.framework.Assert.assertTrue;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class SuperNintendoTeste {
    
    @Test
    public void deveConectarJogo() throws Exception{
    //cenário        
        SuperNintendo snes = new SuperNintendo();             
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);                                                   
    //ação
        snes.conectaJogo(spaceShip);      
    //verificação
        assertTrue(snes.jogoConectado());    
    }

    @Test
    public void deveConectarControle() throws Exception{
    //cenário        
        SuperNintendo snes = new SuperNintendo();             
        ControleGenerico controle = new ControleTecladoDireito();                                               
    //ação
        snes.conectaControle(controle);
    //verificação
        assertTrue(snes.controleConectado());    
    }    

    @Test
    public void deveEnviarComandoParaJogo() throws Exception{
    
    //Deve-se usar MOCKs aqui!    
    /*
    //cenário        
        SuperNintendo snes = new SuperNintendo();             
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);                                              
        snes.conectaJogo(spaceShip);
        ControleGenerico controle = new ControleTecladoDireito();
        snes.conectaControle(controle);
    //ação
        snes.enviaComandoParaJogo(ControleGenerico.start);
        spaceShip.executaCiclo();
        snes.enviaComandoParaJogo(ControleGenerico.start);
        spaceShip.executaCiclo();
    //verificação
        assertTrue(spaceShip.startPressionado());    
    */
    }     
    
}
