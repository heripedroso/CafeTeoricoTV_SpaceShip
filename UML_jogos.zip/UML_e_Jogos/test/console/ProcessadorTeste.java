/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console;

import console.controles.ControleGenerico;
import console.controles.ControleTecladoDireito;
import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;
import static junit.framework.Assert.assertTrue;
import org.junit.Test;

/**
 *
 * @author Heriberto
 */
public class ProcessadorTeste {
    
    @Test
    public void deveConectarJogoPeloSuperNintendo() throws Exception{
    //cenário        
        Tela tela = new Tela();
        Som som = new Som();      
        SuperNintendo snes = new SuperNintendo();
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);  
        
        Processador processador = new Processador(tela, som, snes);
        
        snes.add(tela);    
        snes.setVisible(true);                                                   
    //ação
        snes.conectaJogo(spaceShip);      
    //verificação
        assertTrue(processador.jogoConectado());    
    }    
    @Test
    public void deveConectarControlePeloSuperNintendo() throws Exception{
    //cenário        
        Tela tela = new Tela();
        Som som = new Som();      
        SuperNintendo snes = new SuperNintendo();
        ControleGenerico controle = new ControleTecladoDireito();         
        Processador processador = new Processador(tela, som, snes);                                             
    //ação
        snes.conectaControle(controle);     
    //verificação
        assertTrue(processador.controleConectado());    
    }
    @Test
    public void deveSerLigadoPeloSuperNintendo() throws Exception{
    //cenário        
        Tela tela = new Tela();
        Som som = new Som();      
        SuperNintendo snes = new SuperNintendo();     
        Processador processador = new Processador(tela, som, snes);    
        snes.setProcessador(processador);
    //ação
        snes.ligaConsole();     
    //verificação
        assertTrue(processador.isLigado());    
    }     
    @Test
    public void deveSerDesligadoPeloSuperNintendo() throws Exception{
    //cenário        
        Tela tela = new Tela();
        Som som = new Som();      
        SuperNintendo snes = new SuperNintendo();     
        Processador processador = new Processador(tela, som, snes);    
        snes.setProcessador(processador);
    //ação
        snes.desligaConsole();     
    //verificação
        assertTrue(processador.isDesligado());    
    }    
    
    @Test
    public void deveConectarPincel() throws Exception{
    //cenário        
        Tela tela = new Tela();
        Som som = new Som();      
        SuperNintendo snes = new SuperNintendo();     
        Processador processador = new Processador(tela, som, snes);    
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        Jogo spaceShip = new Jogo(nave,chipGrafico,chipSom);  
        ControleGenerico controle = new ControleTecladoDireito(); 
        
        snes.setProcessador(processador);        
        
        snes.conectaJogo(spaceShip);
        snes.conectaControle(controle);
        
        snes.add(tela);
        snes.setVisible(true);        
    //ação
        processador.conectaPincel(tela.getGraphics());       
    //verificação
        assertTrue(processador.isPincelConectado());    
    } 
}
