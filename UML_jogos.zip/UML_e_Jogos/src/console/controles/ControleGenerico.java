/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console.controles;

import java.awt.event.KeyEvent;

/**
 *
 * @author Heriberto
 */
public interface ControleGenerico{
    
    
    String start = "start";    
    
    String paraDireita = "direita";
    String paraEsquerda = "esquerda";
    String paraBaixo = "baixo";
    String paraCima = "cima";       
            
    String botaoY = "Y";
    String botaoX = "X";
    String botaoB = "B";
    String botaoA = "A";    
    
    public String enviaComando();
    
}
