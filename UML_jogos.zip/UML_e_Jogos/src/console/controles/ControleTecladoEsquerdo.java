/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console.controles;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author Heriberto
 */
public class ControleTecladoEsquerdo implements KeyListener, ControleGenerico{
        
    private String comando = ""; 
    
    public ControleTecladoEsquerdo(){
    }
    
    public void pressionaBotao(KeyEvent tecla){
        int codigo = tecla.getKeyCode();
        if (codigo == KeyEvent.VK_W && !this.comando.contains(this.paraCima)){
            this.comando += this.paraCima;
        }
        if (codigo == KeyEvent.VK_S && !this.comando.contains(this.paraBaixo)){
            this.comando += this.paraBaixo;
        }        
        if (codigo == KeyEvent.VK_D && !this.comando.contains(this.paraDireita)){
            this.comando += this.paraDireita;
        }
        if (codigo == KeyEvent.VK_A && !this.comando.contains(this.paraEsquerda)){
            this.comando += this.paraEsquerda;
        }           
        /*   Botões de ação  */
        if (codigo == KeyEvent.VK_G && !this.comando.contains(this.botaoY)){
            this.comando += this.botaoY;
        }
        if (codigo == KeyEvent.VK_H && !this.comando.contains(this.botaoX)){
            this.comando += this.botaoX;
        }        
        if (codigo == KeyEvent.VK_B && !this.comando.contains(this.botaoB)){
            this.comando += this.botaoB;
        }
        if (codigo == KeyEvent.VK_N && !this.comando.contains(this.botaoA)){
            this.comando += this.botaoA;
        }        
        if (codigo == KeyEvent.VK_T && !this.comando.contains(this.start)){
            this.comando += this.start;
        } 
    }
    
    public void liberaBotao(KeyEvent tecla){
        int codigo = tecla.getKeyCode();
        /*   Direcionais  */
        if (codigo == KeyEvent.VK_W){
            this.comando = this.comando.replace(this.paraCima,"");
        }
        if (codigo == KeyEvent.VK_S){
            this.comando = this.comando.replace(this.paraBaixo,"");
        }        
        if (codigo == KeyEvent.VK_D){
            this.comando = this.comando.replace(this.paraDireita,"");
        }
        if (codigo == KeyEvent.VK_A){
            this.comando = this.comando.replace(this.paraEsquerda,"");
        }           
        /*   Botões de ação  */
        if (codigo == KeyEvent.VK_G){
            this.comando = this.comando.replace(this.botaoY,"");
        }
        if (codigo == KeyEvent.VK_H){
            this.comando = this.comando.replace(this.botaoX,"");
        }        
        if (codigo == KeyEvent.VK_B){
            this.comando = this.comando.replace(this.botaoB,"");
        }
        if (codigo == KeyEvent.VK_N){
            this.comando = this.comando.replace(this.botaoA,"");
        } 
        if (codigo == KeyEvent.VK_T){
            this.comando = this.comando.replace(this.start,"");
        }         
    }

    @Override
    public String enviaComando(){
        //System.out.println("teste");
        return this.comando;
    }
    
    @Override
    public void keyPressed (KeyEvent e){
        this.pressionaBotao(e);
    }
        
    @Override
    public void keyReleased (KeyEvent e){
        this.liberaBotao(e);
    }

    @Override
    public void keyTyped(KeyEvent e) {
        //
    }

}
