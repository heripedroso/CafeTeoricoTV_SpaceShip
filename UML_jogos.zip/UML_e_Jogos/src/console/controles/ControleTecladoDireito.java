/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console.controles;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author Heriberto
 */
public class ControleTecladoDireito implements ControleGenerico, KeyListener {
        
    private String comando = ""; 
    
    public ControleTecladoDireito(){
    }
    
    public void pressionaBotao(KeyEvent tecla){
        int codigo = tecla.getKeyCode();
        
        /*   Direcionais  */
        if (codigo == KeyEvent.VK_UP && !this.comando.contains(this.paraCima)){
            this.comando += this.paraCima;
        }
        if (codigo == KeyEvent.VK_DOWN && !this.comando.contains(this.paraBaixo)){
            this.comando += this.paraBaixo;
        }        
        if (codigo == KeyEvent.VK_RIGHT && !this.comando.contains(this.paraDireita)){
            this.comando += this.paraDireita;
        }
        if (codigo == KeyEvent.VK_LEFT && !this.comando.contains(this.paraEsquerda)){
            this.comando += this.paraEsquerda;
        }           
        /*   Botões de ação  */
        if (codigo == KeyEvent.VK_NUMPAD4 && !this.comando.contains(this.botaoY)){
            this.comando += this.botaoY;
        }
        if (codigo == KeyEvent.VK_NUMPAD5 && !this.comando.contains(this.botaoX)){
            this.comando += this.botaoX;
        }        
        if (codigo == KeyEvent.VK_NUMPAD1 && !this.comando.contains(this.botaoB)){
            this.comando += this.botaoB;
        }
        if (codigo == KeyEvent.VK_NUMPAD2 && !this.comando.contains(this.botaoA)){
            this.comando += this.botaoA;
        }        
        if (codigo == KeyEvent.VK_SPACE && !this.comando.contains(this.start)){
            this.comando += this.start;
        } 
    }
    

    public void liberaBotao(KeyEvent tecla){
        int codigo = tecla.getKeyCode();        
        /*   Direcionais  */
        if (codigo == KeyEvent.VK_UP){
            this.comando = this.comando.replace(this.paraCima,"");
        }
        if (codigo == KeyEvent.VK_DOWN){
            this.comando = this.comando.replace(this.paraBaixo,"");
        }        
        if (codigo == KeyEvent.VK_RIGHT){
            this.comando = this.comando.replace(this.paraDireita,"");
        }
        if (codigo == KeyEvent.VK_LEFT){
            this.comando = this.comando.replace(this.paraEsquerda,"");
        }           
        /*   Botões de ação  */
        if (codigo == KeyEvent.VK_NUMPAD4){
            this.comando = this.comando.replace(this.botaoY,"");
        }
        if (codigo == KeyEvent.VK_NUMPAD5){
            this.comando = this.comando.replace(this.botaoX,"");
        }        
        if (codigo == KeyEvent.VK_NUMPAD1){
            this.comando = this.comando.replace(this.botaoB,"");
        }
        if (codigo == KeyEvent.VK_NUMPAD2){
            this.comando = this.comando.replace(this.botaoA,"");
        } 
        if (codigo == KeyEvent.VK_SPACE){
            this.comando = this.comando.replace(this.start,"");
        } 
    }

    @Override
    public String enviaComando(){
        return this.comando;
    }
    
    @Override
    public void keyPressed (KeyEvent e){
        this.pressionaBotao(e);
    }
        
    @Override
    public void keyReleased (KeyEvent e){
        this.liberaBotao(e);
    }

    @Override
    public void keyTyped(KeyEvent e) {
       //
    }
    

}
