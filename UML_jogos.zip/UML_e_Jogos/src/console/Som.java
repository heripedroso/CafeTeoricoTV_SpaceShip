/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console;

import jogos.spaceship.Jogo;

/**
 *
 * @author Heriberto
 */
public class Som {
    
    private Jogo ref_jogo;
    private Processador ref_processador;
    
    public Som(){
    }
    
    public void conectaProcessador(Processador processador){
        ref_processador = processador;
    }
        
    public void tocaAudios(){
        ref_processador.tocaAudios();        
    }
    
}
