/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

/**
 *
 * @author Heriberto
 */
public class Tela extends JPanel{
    
    private Processador ref_processador;
    private Graphics ref_pincel;
    
    
    public Tela(){    
    }
    
    public void conectaProcessador(Processador processador) throws Exception{
        ref_processador = processador; 
    }
    
    
    @Override
    public void paint(Graphics pincel){
        Graphics2D pincel_2D = (Graphics2D) pincel;                     
        try {
            ref_processador.conectaPincel(pincel_2D);
        } catch (Exception ex) {
            Logger.getLogger(Tela.class.getName()).log(Level.SEVERE, null, ex);
        }        
        ref_processador.desenha();           
    }  

    public Graphics getRef_pincel() {
        return ref_pincel;
    }
        
}
