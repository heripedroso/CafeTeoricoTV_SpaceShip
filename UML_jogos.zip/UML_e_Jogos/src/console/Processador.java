/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComponent;
import javax.swing.Timer;

/**
 *
 * @author Heriberto
 */
public class Processador implements ActionListener{

    private SuperNintendo ref_snes;    

    private Tela ref_tela;  
    private Som ref_som;
    
    private Timer timer;
    
    private boolean ligado;
    private boolean desligado;
    private boolean pincelConectado;
   
    
    public Processador(Tela tela, Som som, SuperNintendo snes) throws Exception{        
        timer = new Timer(10,this); 
        ref_tela = tela;
        ref_som = som;
        ref_snes = snes;        
        
        ref_tela.conectaProcessador(this);
        ref_som.conectaProcessador(this);
        
        ligado = false;
        desligado = false;
    }        
    
    public boolean controleConectado(){
        return ref_snes.controleConectado();
    }
    
    public boolean jogoConectado(){
        return ref_snes.jogoConectado();
    }   
    
    public String enviaComando(){
        return ref_snes.enviaComando();
    } 
    
    public void conectaPincel(Graphics pincel) throws Exception{
        if(pincel == null){
            throw new Exception("Processador diz: Pincel não conectado. Argumento NULO.");
        }
        else{
            this.ref_snes.conectaPincel(pincel);
            this.pincelConectado = true;
        }
    }
    
    public void liga(){  
        timer.start();
        ligado = true;
        desligado = false;
    }

    public void desliga(){    
        timer.stop();
        ligado = false;
        desligado = true;
    }   
    
    public void desenha(){
        ref_snes.desenha();
    }
    
    public void tocaAudios(){        
        ref_snes.tocaAudio();                   
    }     
    
    @Override
    public void actionPerformed(ActionEvent e) {   
        ref_snes.enviaComandoParaJogo();
        ref_snes.executaCicloJogo();        
        ref_tela.repaint();        
        ref_som.tocaAudios();       
        
        //Teste para verificar se comando está chegando até esse ponto
        //System.out.println(ref_snes.enviaComando());
    }

    public boolean isLigado() {
        return ligado;
    }

    public boolean isDesligado() {
        return desligado;
    }

    public boolean isPincelConectado() {
        return pincelConectado;
    }
    
}
