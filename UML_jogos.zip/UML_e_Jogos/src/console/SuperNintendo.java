/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console;

import jogos.spaceship.Jogo;
import console.controles.ControleGenerico;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class SuperNintendo extends JFrame{
    
    private ControleGenerico ref_controle;  
    
    private Jogo ref_jogo;    
    
    private Processador processador;   
    private Tela tela;
    private Som som;
    private Graphics ref_pincel;
    
    private boolean gatilho_som;
           
    public SuperNintendo() throws Exception{        
        
        this.setTitle("Oi, mundo!");
        this.setSize(1024,600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);        
                        
        tela = new Tela();
        som = new Som();          
        
        processador = new Processador(tela, som, this);
        
        this.add(tela);    
        this.setVisible(true); 

    }
    
    public void conectaControle(ControleGenerico controle) throws Exception{ 
        if(controle == null){
            throw new Exception("SuperNinentendo diz: Controle não conectado. Argumento NULO.");
        }
        else{
            this.addKeyListener((KeyListener) controle);
            this.ref_controle = (ControleGenerico) controle; 
        }
    }

    public void conectaJogo(Jogo jogo) throws Exception{      
        if(jogo == null){
            throw new Exception("SuperNinentendo diz: Jogo não conectado. Argumento NULO.");
        }
        else{
            this.ref_jogo = jogo;
            this.conectaTela();
        }    
    }     
    
    public void ligaConsole(){     
        processador.liga();         
        gatilho_som = true;
    }

    public void desligaConsole(){                                        
        processador.desliga();
    }         
    
    public String enviaComando(){
        return ref_controle.enviaComando();
    }
    
    public boolean controleConectado(){
        return ref_controle != null;
    }
 
    public boolean jogoConectado(){
        return ref_jogo != null;
    }    
    
    public void conectaTela(){
        if(this.jogoConectado()){          
            ref_jogo.conectaTela(this.tela);
            ref_jogo.confirmaTelaConectada();
        }
    }
    
    public void conectaPincel(Graphics pincel) throws Exception{
        if(pincel == null){
            throw new Exception("SuperNinentendo diz: Pincel não conectado. Argumento NULO.");
        }
        else{
            if(this.jogoConectado()){  
                ref_jogo.conectaPincel(pincel);
                ref_jogo.confirmaPincelConectado();
            }
            else{
                ref_pincel = pincel;
            }
        }
    }
    
    private void desenhaImagemSNES(){  
        Image icon = new ImageIcon("imagens\\cafe_starting.gif").getImage();
        ref_pincel.drawImage(icon,0,0,tela);
    }
    
    public void desenha(){
        if(this.jogoConectado()){            
            ref_jogo.enviaVideo();
        }
        else{
            this.desenhaImagemSNES();
        }   
    }
    private void tocaAudioSNES(){
        Clip clip;
        AudioInputStream audioInputStream;   
                                 
        if(gatilho_som){
            try {
                audioInputStream = AudioSystem.getAudioInputStream(new File("audios\\sony-playstation-startup.mid").getAbsoluteFile());
                clip = AudioSystem.getClip();
                clip.open(audioInputStream);               
                clip.start();
            } catch (IOException | LineUnavailableException | UnsupportedAudioFileException ex) {
                System.out.println("SuperNinentendo diz: Erro ao executar SOM!");                
            }      
            gatilho_som = false;
        }          
    }
    
    public void tocaAudio(){
        if(this.jogoConectado()){            
            ref_jogo.tocaAudios();
        }
        else{
            this.tocaAudioSNES();
        }
    }
    
    public void executaCicloJogo(){
        if(this.jogoConectado()){            
            ref_jogo.executaCiclo();
        }        
    }
    
    public void enviaComandoParaJogo(){
        if(this.jogoConectado()){            
            ref_jogo.recebeComando(this.enviaComando());
        }         
    }

    public void enviaComandoParaJogo(String comando){
        if(this.jogoConectado()){            
            ref_jogo.recebeComando(comando);
        }         
    }    

    public Tela getTela() {
        return tela;
    }

    public void setProcessador(Processador processador) {
        this.processador = processador;
    }
        
}
