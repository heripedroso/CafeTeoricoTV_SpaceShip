/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package console;

import console.controles.ControleGenerico;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import jogos.spaceship.Jogo;



public class SuperNintendo extends JPanel implements ActionListener{
    
    private ControleGenerico ref_controle;  
    
    private Jogo ref_jogo;    
    
    private JFrame janela;    
    
    private Timer timer;
           
    public SuperNintendo(ControleGenerico controle, Jogo jogo){                
        
        this.janela = new JFrame();
        this.janela.setTitle("Oi, mundo!");
        this.janela.setSize(1024,600);
        this.janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.janela.setLocationRelativeTo(null);
        this.janela.setResizable(false);   

        this.janela.addKeyListener((KeyListener) controle);
        this.ref_controle = (ControleGenerico) controle; 

        this.ref_jogo = jogo;        
        
        this.janela.add(this);
        this.janela.setVisible(true);        
        this.setVisible(true);

        timer = new Timer(5,this);
        timer.start();
   
    }
       
    @Override
    public void paint(Graphics pincel){
        Graphics2D pincel_2D = (Graphics2D) pincel;                     
        this.ref_jogo.conectaPincel(pincel_2D);
        this.ref_jogo.conectaTela(this);
        this.ref_jogo.desenha();
    }         
    
    public void tocaAudio(){        
        ref_jogo.tocaAudios();
    }    
        

    @Override
    public void actionPerformed(ActionEvent e) {
        this.ref_jogo.recebeComando(ref_controle.enviaComando());
        this.ref_jogo.executaCiclo();
        this.repaint();
        this.tocaAudio();
       
    }
}
