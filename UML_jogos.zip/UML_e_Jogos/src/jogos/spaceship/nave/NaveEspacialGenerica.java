/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave;

import java.util.List;
import jogos.spaceship.nave.canhao.TiroGenerico;

/**
 *
 * @author Heriberto
 */
public interface NaveEspacialGenerica {
    
    public int getX();
    public int getY();
    public void setX(int x);
    public void setY(int y);
    
    public void setPosicaoInicial();

    public void recebeComando(String comando);
    
    public int getLargura();
    public int getAltura();
    
    public List<TiroGenerico> getRajada_tiros();
    
    public void executaCiclo();
    public String getComando();
    public int getContador_carrega_tiro();
    
    public void setPasso(int velocidade_deslocamento);
    
    public boolean isAbatida();
    public void setAbatida(boolean abatida);

    public void tocaAudio();
    public void desenha();    
}
