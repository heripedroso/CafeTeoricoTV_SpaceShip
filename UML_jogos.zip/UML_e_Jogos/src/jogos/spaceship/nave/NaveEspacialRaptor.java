/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave;

import jogos.spaceship.nave.painel.PainelDeControle;
import jogos.spaceship.nave.canhao.CanhaoRaptor;
import jogos.spaceship.movimento.nave.MovimentoNave;
import console.controles.ControleGenerico;
import java.util.List;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.movimento.MovimentoGenerico;
import jogos.spaceship.nave.canhao.tiro.TiroGenerico;

/**
 *
 * @author Heriberto
 */
public class NaveEspacialRaptor implements NaveEspacialGenerica{
    
    private String comando;
    
    private MovimentoGenerico movimentacaoNave;    
    
    private boolean abatida;
    
    private ChipGrafico ref_chip_grafico;  
    private ChipSom ref_chipSom;
    
    private CanhaoRaptor canhaoRaptor;
    
    private PainelDeControle painel;
    
    public NaveEspacialRaptor(ChipGrafico chipGrafico, ChipSom chipSom){
                           
        this.ref_chip_grafico = chipGrafico;
        
        this.setAbatida(false);
        
        movimentacaoNave = new MovimentoNave(100, 100, 6, chipGrafico);  
        
        canhaoRaptor = new CanhaoRaptor(this, chipGrafico, chipSom);
        
        painel = new PainelDeControle();        
        painel.conectaNave(this);  
        painel.conectaChipGrafico(chipGrafico);        
    }

    @Override
    public void setPasso(int velocidade_deslocamento) {
        this.movimentacaoNave.setPasso(velocidade_deslocamento);
    }
    
    @Override
    public int getX() {
        return this.movimentacaoNave.getX();
    }
    
    @Override
    public int getY() {
        return this.movimentacaoNave.getY();
    }

    @Override
    public void setX(int x) {
        this.movimentacaoNave.setX(x);
    }

    @Override
    public void setY(int y) {
        this.movimentacaoNave.setY(y);
    }
    
    @Override
    public void setPosicaoInicial(){
        this.setX(100);
        this.setY(100);
    }    
    
    @Override
    public void recebeComando(String comando) {
        this.comando = comando;        
        this.canhaoRaptor.recebeComando(comando);
    }          

    @Override
    public boolean isAbatida() {
        return abatida;
    }

    @Override
    public void setAbatida(boolean abatida) {
        this.abatida = abatida;
    }

    @Override
    public String getComando() {
        return comando;
    }                                 

    @Override
    public int getContador_carrega_tiro() {
        return this.canhaoRaptor.getContador_energia();
    }

    @Override
    public int getLargura() {
        return this.ref_chip_grafico.getLargura_raptor();
    }

    @Override
    public int getAltura() {
        return this.ref_chip_grafico.getAltura_raptor();
    }

    @Override
    public List<TiroGenerico> getRajada_tiros() {
        return this.canhaoRaptor.getRajada_tiros();
    }
    
    @Override
    public void executaCiclo() {              
        
        /* Nova posição da nave após o recebimento do comando */
        if (this.comando.contains(ControleGenerico.paraCima)){
            this.movimentacaoNave.paraCima();    
        }
        if (this.comando.contains(ControleGenerico.paraBaixo)){
            this.movimentacaoNave.paraBaixo();
        }
        if (this.comando.contains(ControleGenerico.paraEsquerda)){
            this.movimentacaoNave.paraEsquerda();
        }
        if (this.comando.contains(ControleGenerico.paraDireita)){
            this.movimentacaoNave.paraDireita();
        }                 
    }    

    @Override
    public void desenha(){
        
        this.movimentacaoNave.desenha(); 
        this.painel.desenha();
        this.canhaoRaptor.desenha();
    }
    
    @Override
    public void tocaAudio() {
        canhaoRaptor.tocaAudio();
    }

    
}
