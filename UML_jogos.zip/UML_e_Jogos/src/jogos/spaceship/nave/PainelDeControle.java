/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave;

import jogos.spaceship.nave.canhao.TiroSimples;
import jogos.spaceship.nave.canhao.TiroForte;
import jogos.spaceship.nave.canhao.TiroMedio;
import java.awt.Color;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.canhao.CanhaoRaptor;

/**
 *
 * @author Heriberto
 */
public class PainelDeControle {
    
    private ChipGrafico ref_chipGrafico;
    
    private CanhaoRaptor canhao;
    
    private int energia_amarela_01;
    private int energia_amarela_02;
    private int energia_laranja_01;
    private int energia_laranja_02;
    private int energia_vermelha_01;
    private int energia_vermelha_02;
    
    private int x_retangulo;
    private int y_retangulo;

    public PainelDeControle(CanhaoRaptor canhao, ChipGrafico chipGrafico) {
        this.energia_amarela_01 = (new TiroSimples(new ChipGrafico())).getMinimo_energia_carregada();
        this.energia_amarela_02 = (new TiroSimples(new ChipGrafico())).getMaximo_energia_carregada();
        
        this.energia_laranja_01 = (new TiroMedio(new ChipGrafico())).getMinimo_energia_carregada();
        this.energia_laranja_02 = (new TiroMedio(new ChipGrafico())).getMaximo_energia_carregada();
        
        this.energia_vermelha_01 = (new TiroForte(new ChipGrafico())).getMinimo_energia_carregada();
        this.energia_vermelha_02 = (new TiroForte(new ChipGrafico())).getMaximo_energia_carregada();
        
        this.ref_chipGrafico = chipGrafico;
        
        this.canhao = canhao;
        
        this.x_retangulo = 10;
        this.y_retangulo = 10; 
    }     
    
    
    private void recebeContadorEnergia(){

        if (this.canhao.getContador_energia() > 0){  
             if((this.canhao.getContador_energia() >= energia_amarela_01)&& (this.canhao.getContador_energia() <= energia_amarela_02)){
                 ref_chipGrafico.getPincel().setColor(Color.YELLOW); 
             }
             if((this.canhao.getContador_energia()>= energia_laranja_01) && (this.canhao.getContador_energia() <= energia_laranja_02)){
                 ref_chipGrafico.getPincel().setColor(Color.ORANGE);
             }
             if((this.canhao.getContador_energia() >= energia_vermelha_01) && (this.canhao.getContador_energia() <= energia_vermelha_02)){
                 ref_chipGrafico.getPincel().setColor(Color.RED);
             }                           
         }else{
            ref_chipGrafico.getPincel().setColor(Color.GREEN); 
         }        

    }
    
    public void desenha(){    
        
        this.recebeContadorEnergia();

        ref_chipGrafico.getPincel().drawRect(x_retangulo,y_retangulo,this.energia_amarela_02*5,10);
        ref_chipGrafico.getPincel().drawRect(x_retangulo,y_retangulo,this.energia_laranja_02*5,10);
        ref_chipGrafico.getPincel().drawRect(x_retangulo,y_retangulo,this.energia_vermelha_02*5,10);
        ref_chipGrafico.getPincel().drawRect(x_retangulo,y_retangulo,this.canhao.getContador_energia()*5,10);  
        ref_chipGrafico.getPincel().fillRect(x_retangulo,y_retangulo,this.canhao.getContador_energia()*5,10);       
    }                       
    
}
