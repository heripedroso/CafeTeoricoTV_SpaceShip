/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave.canhao.tiro;

import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author Heriberto
 */
public interface TiroGenerico {
       
    public int getMinimo_energia_carregada();   
    public int getMaximo_energia_carregada();
    public boolean getVisivel();    
    
    public void eDisparado(int x_nave, int y_nave);    
    public void seMovimenta();
    public void desenha();
    
    public int getX();
    public int getY();
    
    public int getLargura();
    public int getAltura();


}
