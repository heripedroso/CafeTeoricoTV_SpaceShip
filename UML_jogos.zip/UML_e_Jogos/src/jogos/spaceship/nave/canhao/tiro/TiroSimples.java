/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave.canhao.tiro;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.movimento.MovimentoGenerico;
import jogos.spaceship.movimento.nave.tiro.MovimentoTiroSimples;

/**
 *
 * @author Heriberto
 */
public class TiroSimples implements TiroGenerico{

    private int velocidade_deslocamento;

    private int minimo_energia_carregada;
    private int maximo_energia_carregada;
    
    private MovimentoGenerico movimentacaoTiroSimples;
    
    private ChipGrafico ref_chipGrafico;    
    
    public TiroSimples(ChipGrafico chipGrafico){
                                        
        this.minimo_energia_carregada = 1;
        this.maximo_energia_carregada = 37;                     
        
        this.velocidade_deslocamento = 20; 
        
        this.ref_chipGrafico = chipGrafico; 
                
    }   

    //A movimentaçao é iniciada
    @Override
    public void eDisparado(int x_nave, int y_nave){
        int x;
        int y;
        
        x = x_nave-this.ref_chipGrafico.getLargura_raptor()/2;
        y = y_nave+(this.ref_chipGrafico.getAltura_raptor()/2)-(this.ref_chipGrafico.getAltura_imagem_tiro_simples()/2);
        
        movimentacaoTiroSimples = new MovimentoTiroSimples(x,y,velocidade_deslocamento,ref_chipGrafico);
        
    }   

    @Override
    public void seMovimenta() {           
        this.movimentacaoTiroSimples.movimenta();
    }   
    
    @Override
    public void desenha(){
            this.movimentacaoTiroSimples.desenha();
    }

    @Override
    public int getMinimo_energia_carregada() {
        return minimo_energia_carregada;
    }

    @Override
    public int getMaximo_energia_carregada() {
        return maximo_energia_carregada;
    }
    @Override
    public boolean getVisivel() {
        return this.movimentacaoTiroSimples.isVisivel();
    }
    @Override
    public int getX(){
        return this.movimentacaoTiroSimples.getX();        
    }
    @Override
    public int getY(){
        return this.movimentacaoTiroSimples.getY();
    }
    @Override
    public int getLargura(){
        return this.ref_chipGrafico.getLargura_imagem_tiro_simples();        
    }
    @Override
    public int getAltura(){
        return this.ref_chipGrafico.getAltura_imagem_tiro_simples();
    }    
    

}
