/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave.canhao;

import jogos.spaceship.movimento.MovimentoTiroForte;
import java.util.logging.Level;
import java.util.logging.Logger;
import jogos.spaceship.SomImagem.ChipGrafico;

/**
 *
 * @author Heriberto
 */
public class TiroForte implements TiroGenerico{

    private int velocidade_deslocamento;

    private int minimo_energia_carregada;
    private int maximo_energia_carregada;
    
    private MovimentoTiroForte movimentacaoTiroForte;
    
    ChipGrafico ref_chipGrafico;
    
    
    public TiroForte(ChipGrafico chipGrafico){
                      
        this.velocidade_deslocamento = 40; 
                
        this.minimo_energia_carregada = 74;
        this.maximo_energia_carregada = 75;
        
        this.ref_chipGrafico = chipGrafico;                       
    }
    

    public void eDisparado(int x_nave, int y_nave){
        int x;
        int y;
        
        x = x_nave-this.ref_chipGrafico.getLargura_raptor()/2;
        y = y_nave+(this.ref_chipGrafico.getAltura_raptor()/2)-(this.ref_chipGrafico.getAltura_imagem_tiro_forte()/2);
        
        movimentacaoTiroForte = new MovimentoTiroForte(x,y,velocidade_deslocamento,ref_chipGrafico);        
    }
    
    
    public void seMovimenta() {           
        this.movimentacaoTiroForte.movimenta();      
    }   
    public void desenha(){
        this.movimentacaoTiroForte.desenha();
    }

    @Override
    public boolean getVisivel() {
        return this.movimentacaoTiroForte.isVisivel();
    }

    @Override
    public int getMinimo_energia_carregada() {
        return this.minimo_energia_carregada;
    }

    @Override
    public int getMaximo_energia_carregada() {
        return this.maximo_energia_carregada;
    }    
    
    @Override
    public int getX(){
        return this.movimentacaoTiroForte.getX();        
    }
    @Override
    public int getY(){
        return this.movimentacaoTiroForte.getY();
    }
    @Override
    public int getLargura(){
        return this.ref_chipGrafico.getLargura_imagem_tiro_forte();        
    }
    @Override
    public int getAltura(){
        return this.ref_chipGrafico.getAltura_imagem_tiro_forte();
    }       
}
