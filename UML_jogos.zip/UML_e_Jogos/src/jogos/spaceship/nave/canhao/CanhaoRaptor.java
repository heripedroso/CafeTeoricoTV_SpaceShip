/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave.canhao;

import jogos.spaceship.nave.canhao.tiro.TiroSimples;
import jogos.spaceship.nave.canhao.tiro.TiroForte;
import jogos.spaceship.nave.canhao.tiro.TiroGenerico;
import jogos.spaceship.nave.canhao.tiro.TiroMedio;
import console.controles.ControleGenerico;
import java.util.ArrayList;
import java.util.List;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.nave.NaveEspacialGenerica;

/**
 *
 * @author Heriberto
 */
public class CanhaoRaptor {
    
   private TiroSimples tiroSimples;
   private TiroMedio tiroMedio;
   private TiroForte tiroForte;
   
   private List<TiroGenerico> rajada_tiros = new ArrayList(); 
      
   private NaveEspacialGenerica ref_nave;
   
   private String comando;
   
   private int contador_energia;
   
   private ChipGrafico ref_chipGrafico;   
   private ChipSom ref_chipSom; 
   
   private boolean tiroSimplesDisparado;
   private boolean tiroMedioDisparado;
   private boolean tiroForteDisparado;
      
   public CanhaoRaptor(NaveEspacialGenerica nave, ChipGrafico chipGrafico, ChipSom chipSom){       
       this.tiroSimples = new TiroSimples(chipGrafico);
       this.tiroMedio = new TiroMedio(chipGrafico);
       this.tiroForte = new TiroForte(chipGrafico);
       
       this.ref_nave = nave;
       this.ref_chipGrafico = chipGrafico;  
       this.ref_chipSom = chipSom;
   }
   
   public void recebeComando(String comando){
       this.comando = comando;
       if(comando.contains(ControleGenerico.botaoY)){
          this.carregaEnergia();
       }   
       if(this.tiroDisparado()){
            this.atira();
            this.descarregaEnergia();
       }     
   }
   
   //Affirmation 01
   public boolean tiroSimplesCarregado(){
        return contador_energia >= tiroSimples.getMinimo_energia_carregada() && contador_energia < tiroSimples.getMaximo_energia_carregada();            
   }

   //Affirmation 02 
   public boolean tiroMedioCarregado(){
        return contador_energia >= tiroMedio.getMinimo_energia_carregada() && contador_energia < tiroMedio.getMaximo_energia_carregada();            
   }   
   
   //Affirmation 03
   public boolean tiroForteCarregado(){
        return contador_energia >= tiroForte.getMinimo_energia_carregada() && contador_energia <= tiroForte.getMaximo_energia_carregada();            
   } 
   
   //Affirmation 04
   public boolean tiroDisparado(){
        return (this.tiroSimplesCarregado() || this.tiroMedioCarregado() || this.tiroForteCarregado()) && !comando.contains("Y");
   }
   
   //Altera o estado interno do objeto
   public void carregaEnergia(){
       this.contador_energia = this.contador_energia + 1; 
       if(this.contador_energia > tiroForte.getMaximo_energia_carregada())
             this.contador_energia = tiroForte.getMaximo_energia_carregada();
   }
   
   public void descarregaEnergia(){
       this.contador_energia = 0;
   }
   
   public void atira(){
      
        TiroGenerico tiroGenerico;    
        
        if(this.tiroSimplesCarregado()){
             tiroGenerico = new TiroSimples(ref_chipGrafico); 
             tiroGenerico.eDisparado(ref_nave.getX(),ref_nave.getY());   
             this.rajada_tiros.add(tiroGenerico);
             tiroSimplesDisparado = true;
        }
        if(this.tiroMedioCarregado()){
             tiroGenerico = new TiroMedio(ref_chipGrafico); 
             tiroGenerico.eDisparado(ref_nave.getX(),ref_nave.getY());   
             this.rajada_tiros.add(tiroGenerico);
             tiroMedioDisparado = true;
        }
        if(this.tiroForteCarregado()){           
             tiroGenerico = new TiroForte(ref_chipGrafico); 
             tiroGenerico.eDisparado(ref_nave.getX(),ref_nave.getY());   
             this.rajada_tiros.add(tiroGenerico);
             tiroForteDisparado = true;
        }
   } 
   
   public void desenha(){
        //Continua os disparos dos tiros que ainda estão visíveis.
        if(!this.rajada_tiros.isEmpty()){
           for(int i=0;i<this.rajada_tiros.size();i++){
              this.rajada_tiros.get(i).seMovimenta(); 
              this.rajada_tiros.get(i).desenha();
           }    
        }      
   }

    public int getContador_energia() {
        return contador_energia;
    }
    
    public List<TiroGenerico> getRajada_tiros() {
        return rajada_tiros;
    }  
    
    public void tocaAudio(){
        if(tiroSimplesDisparado){
            //this.ref_chipSom.gatilhoTiroSimplesDisparado(true);
            this.ref_chipSom.tocaTiroSimples();
            tiroSimplesDisparado = false;
        }
        if(tiroMedioDisparado){
            //this.ref_chipSom.gatilhoTiroMedioDisparado(true);
            this.ref_chipSom.tocaTiroMedio();
            tiroMedioDisparado = false;
        }
        if(tiroForteDisparado){
            //this.ref_chipSom.gatilhoTiroForteDisparado(true);
            this.ref_chipSom.tocaTiroForte();
            tiroForteDisparado = false;
        }  
        this.ref_chipSom.recebeContadorEnergia(this.contador_energia);    
    }
   
}
