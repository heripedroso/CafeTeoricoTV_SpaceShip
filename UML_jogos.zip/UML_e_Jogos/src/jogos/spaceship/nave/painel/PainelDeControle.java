/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.nave.painel;

import jogos.spaceship.nave.canhao.tiro.TiroSimples;
import jogos.spaceship.nave.canhao.tiro.TiroForte;
import jogos.spaceship.nave.canhao.tiro.TiroMedio;
import jogos.spaceship.nave.NaveEspacialGenerica;
import java.awt.Color;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.nave.NaveEspacialGenerica;

/**
 *
 * @author Heriberto
 */
public class PainelDeControle {
    
    private ChipGrafico ref_chipGrafico;
    
    private NaveEspacialGenerica ref_nave;
    
    private int energia_amarela_01;
    private int energia_amarela_02;
    private int energia_laranja_01;
    private int energia_laranja_02;
    private int energia_vermelha_01;
    private int energia_vermelha_02;
    
    private int x_retangulo;
    private int y_retangulo;

    public PainelDeControle() {
        this.energia_amarela_01 = (new TiroSimples(new ChipGrafico())).getMinimo_energia_carregada();
        this.energia_amarela_02 = (new TiroSimples(new ChipGrafico())).getMaximo_energia_carregada();
        
        this.energia_laranja_01 = (new TiroMedio(new ChipGrafico())).getMinimo_energia_carregada();
        this.energia_laranja_02 = (new TiroMedio(new ChipGrafico())).getMaximo_energia_carregada();
        
        this.energia_vermelha_01 = (new TiroForte(new ChipGrafico())).getMinimo_energia_carregada();
        this.energia_vermelha_02 = (new TiroForte(new ChipGrafico())).getMaximo_energia_carregada();
    }
    
    public void conectaChipGrafico(ChipGrafico chipGrafico){
        this.ref_chipGrafico = chipGrafico;
    }
 
    public void conectaNave(NaveEspacialGenerica nave){
        this.ref_nave = nave;
    }   
    
    private void setPosicao(){
        /* Define a posição do painel de controle a partir dos comandos recebidos pelo Controle 01 e Controle 02 */              
        if(ref_nave.getComando().contains("Controle 01")){ 
            x_retangulo = 10;
            y_retangulo = 10;
        }
        if(ref_nave.getComando().contains("Controle 02")){ 
            x_retangulo = ref_chipGrafico.getLargura_imagem_fundo()-(energia_vermelha_02*5+10);
            y_retangulo = 10;
        }               
    }
    
    private void defineCorPincel(){
        if (ref_nave.getComando().contains("Y")){  
             if((ref_nave.getContador_carrega_tiro() >= energia_amarela_01)&& (ref_nave.getContador_carrega_tiro() <= energia_amarela_02)){
                 ref_chipGrafico.getPincel().setColor(Color.YELLOW); 
             }
             if((ref_nave.getContador_carrega_tiro() >= energia_laranja_01) && (ref_nave.getContador_carrega_tiro() <= energia_laranja_02)){
                 ref_chipGrafico.getPincel().setColor(Color.ORANGE);
             }
             if((ref_nave.getContador_carrega_tiro() >= energia_vermelha_01) && (ref_nave.getContador_carrega_tiro() <= energia_vermelha_02)){
                 ref_chipGrafico.getPincel().setColor(Color.RED);
             }                           
         }else{
            ref_chipGrafico.getPincel().setColor(Color.GREEN); 
         }        
    }
    
    public void desenha(){
        
        this.setPosicao();
        
        this.defineCorPincel();
        
        ref_chipGrafico.getPincel().drawRect(x_retangulo,y_retangulo,this.energia_amarela_02*5,10);
        ref_chipGrafico.getPincel().drawRect(x_retangulo,y_retangulo,this.energia_laranja_02*5,10);
        ref_chipGrafico.getPincel().drawRect(x_retangulo,y_retangulo,this.energia_vermelha_02*5,10);
        ref_chipGrafico.getPincel().drawRect(x_retangulo,y_retangulo,ref_nave.getContador_carrega_tiro()*5,10);  
        ref_chipGrafico.getPincel().fillRect(x_retangulo,y_retangulo,ref_nave.getContador_carrega_tiro()*5,10);       
    
    }                       
    
}
