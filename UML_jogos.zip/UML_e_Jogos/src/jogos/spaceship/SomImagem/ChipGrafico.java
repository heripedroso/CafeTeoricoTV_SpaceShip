/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.SomImagem;

import console.Tela;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author Heriberto
 */
public class ChipGrafico {
    
    private Graphics ref_pincel;
    private JPanel ref_tela;
    
    private Image imagem_fundo;
    private Image imagem_fundo_game_over;
    private Image imagem_tiro_forte;
    private Image imagem_tiro_medio;
    private Image imagem_tiro_simples;
    private Image imagem_raptor;
    private Image imagem_nave_destruida;
    private Image imagem_corona;
    private Image imagem_background_jogo_finalizado;
    private Image imagem_background_press_start_prox_fase;    
    
    private int altura_imagem_fundo;
    private int largura_imagem_fundo;
    
    private int altura_imagem_fundo_game_over;
    private int largura_imagem_fundo_game_over;
    
    private int altura_imagem_tiro_forte;
    private int largura_imagem_tiro_forte;
    
    private int altura_imagem_tiro_medio;
    private int largura_imagem_tiro_medio;
    
    private int altura_imagem_tiro_simples;
    private int largura_imagem_tiro_simples;
    
    private int altura_raptor;
    private int largura_raptor;
    
    private int altura_corona;
    private int largura_corona;
        
    public ChipGrafico(){
        ImageIcon imagem_01 = new ImageIcon("imagens\\background_espaco_ajustado_02.jpg");    
        imagem_fundo = imagem_01.getImage();  
        altura_imagem_fundo = imagem_fundo.getHeight(null);
        largura_imagem_fundo = imagem_fundo.getWidth(null);  
        

        ImageIcon imagem_02 = new ImageIcon("imagens\\game_over.jpg");    
        imagem_fundo_game_over = imagem_02.getImage();       
        altura_imagem_fundo_game_over = imagem_fundo_game_over.getHeight(null);
        largura_imagem_fundo_game_over = imagem_fundo_game_over.getWidth(null);  
        
        ImageIcon imagem_03 = new ImageIcon("imagens\\tiro_forte_ajustado.png");        
        imagem_tiro_forte = imagem_03.getImage();
        altura_imagem_tiro_forte = imagem_tiro_forte.getHeight(null);
        largura_imagem_tiro_forte = imagem_tiro_forte.getWidth(null);     

        ImageIcon imagem_04 = new ImageIcon("imagens\\tiro_medio_ajustado.png");        
        imagem_tiro_medio = imagem_04.getImage();
        altura_imagem_tiro_medio = imagem_tiro_medio.getHeight(null);
        largura_imagem_tiro_medio = imagem_tiro_medio.getWidth(null);        
        
        ImageIcon imagem_05 = new ImageIcon("imagens\\tiro_simples_ajustado.png");        
        imagem_tiro_simples = imagem_05.getImage();
        altura_imagem_tiro_simples = imagem_tiro_simples.getHeight(null);
        largura_imagem_tiro_simples = imagem_tiro_simples.getWidth(null);       
        
        ImageIcon imagem_06 = new ImageIcon("imagens\\raptor_ajustado.png");        
        imagem_raptor = imagem_06.getImage();
        altura_raptor = imagem_raptor.getHeight(null);
        largura_raptor = imagem_raptor.getWidth(null);     

        ImageIcon imagem_07 = new ImageIcon("imagens\\corona.png");        
        imagem_corona = imagem_07.getImage();
        altura_corona = imagem_corona.getHeight(null);
        largura_corona = imagem_corona.getWidth(null);            

        ImageIcon imagem_08 = new ImageIcon("imagens\\explosion.png");        
        imagem_nave_destruida = imagem_08.getImage();                   
        
        ImageIcon imagem_10 = new ImageIcon("imagens\\cafe_jogo_finalizado.gif");        
        imagem_background_jogo_finalizado = imagem_10.getImage();    

        ImageIcon imagem_11 = new ImageIcon("imagens\\background_press_start_proxima_fase.jpg");        
        imagem_background_press_start_prox_fase = imagem_11.getImage();           
    }       
    
    public void conectaPincel(Graphics pincel){
       this.ref_pincel = pincel;
    }    
    
    public void conectaTela(Tela tela){
       this.ref_tela = tela;
    }
    
    public void desenhaTiroSimples(int x,int y){
        ref_pincel.drawImage(this.imagem_tiro_simples,x+this.largura_raptor/2,y,this.ref_tela);
    }
    
    public void desenhaTiroMedio(int x,int y){
        ref_pincel.drawImage(this.imagem_tiro_medio,x+this.largura_raptor/2,y,this.ref_tela);
    }    

    public void desenhaTiroForte(int x,int y){
        ref_pincel.drawImage(this.imagem_tiro_forte,x+this.largura_raptor/2,y,this.ref_tela);
    } 
    
    public void desenhaBackground(){
        ref_pincel.drawImage(imagem_fundo,0,0,null);
    }

    public void desenhaBackgroundGameOver(){
        ref_pincel.drawImage(imagem_fundo_game_over,0,0,null);
    }

    public void desenhaBackGroundJogoFinalizado(){        
        ref_pincel.drawImage(this.imagem_background_jogo_finalizado,0,0,null);
    }     

    public void desenhaBackGroundProximaFase(){        
        ref_pincel.drawImage(this.imagem_background_press_start_prox_fase,0,0,null);
    }     
    
    public void desenhaInimigoCorona(int x, int y){
        ref_pincel.drawImage(this.imagem_corona,x,y,ref_tela);
    }
    
    public void desenhaNaveEspacialRaptor(int x, int y){        
        ref_pincel.drawImage(this.imagem_raptor,x,y,ref_tela);
    }    

    public void desenhaNaveEspacialDestruida(int x, int y){        
        ref_pincel.drawImage(this.imagem_nave_destruida,x,y,ref_tela);
    } 
    
    public int getAltura_imagem_fundo() {
        return altura_imagem_fundo;
    }

    public int getLargura_imagem_fundo() {
        return largura_imagem_fundo;
    }

    public int getAltura_imagem_fundo_game_over() {
        return altura_imagem_fundo_game_over;
    }

    public int getLargura_imagem_fundo_game_over() {
        return largura_imagem_fundo_game_over;
    }

    public int getAltura_imagem_tiro_forte() {
        return altura_imagem_tiro_forte;
    }

    public int getLargura_imagem_tiro_forte() {
        return largura_imagem_tiro_forte;
    }

    public int getAltura_imagem_tiro_medio() {
        return altura_imagem_tiro_medio;
    }

    public int getLargura_imagem_tiro_medio() {
        return largura_imagem_tiro_medio;
    }

    public int getAltura_imagem_tiro_simples() {
        return altura_imagem_tiro_simples;
    }

    public int getLargura_imagem_tiro_simples() {
        return largura_imagem_tiro_simples;
    }

    public int getAltura_raptor() {
        return altura_raptor;
    }

    public int getLargura_raptor() {
        return largura_raptor;
    }

    public int getAltura_corona() {
        return altura_corona;
    }

    public int getLargura_corona() {
        return largura_corona;
    }

    public Graphics getPincel() {
        return ref_pincel;
    }
    
}
