/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.SomImagem;

import jogos.spaceship.nave.canhao.TiroForte;
import jogos.spaceship.nave.canhao.TiroMedio;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class ChipSom {
        
    private Clip clip_energia_tiro_medio;
    private Clip clip_energia_tiro_forte;     
    private Clip clip_fase;
    private Clip clip_tiro_simples;
    private Clip clip_tiro_medio;
    private Clip clip_tiro_forte;
    private Clip clip_nave_destruida;
    private Clip clip_inimigo_destruido;    
    private Clip clip_course_clear;
    private Clip clip_game_over;
    private Clip clip_jogo_finalizado;
    private Clip clip_jogo_abertura;
    
    private int var_aux_contador_energia;
    private int var_aux_limite_maximo_tiro_forte;
    private int var_aux_limite_minimo_tiro_medio;

    public ChipSom() {        
        this.var_aux_limite_maximo_tiro_forte = (new TiroForte(new ChipGrafico())).getMaximo_energia_carregada();
        this.var_aux_limite_minimo_tiro_medio = (new TiroMedio(new ChipGrafico())).getMinimo_energia_carregada();  
        this.setAudios();
    }
     
    public void setAudios(){
        AudioInputStream audioInputStream_01;
        AudioInputStream audioInputStream_02;
        AudioInputStream audioInputStream_03;
        AudioInputStream audioInputStream_04;
        AudioInputStream audioInputStream_05;
        AudioInputStream audioInputStream_06;
        AudioInputStream audioInputStream_07;
        AudioInputStream audioInputStream_08;
        AudioInputStream audioInputStream_09;
        
        try {
            audioInputStream_01 = AudioSystem.getAudioInputStream(new File("audios\\tiro_medio_carregado.wav").getAbsoluteFile());
            clip_energia_tiro_medio = AudioSystem.getClip();
            clip_energia_tiro_medio.open(audioInputStream_01); 

            audioInputStream_02 = AudioSystem.getAudioInputStream(new File("audios\\tiro_forte_carregado.wav").getAbsoluteFile());
            clip_energia_tiro_forte = AudioSystem.getClip();
            clip_energia_tiro_forte.open(audioInputStream_02);  

            audioInputStream_03 = AudioSystem.getAudioInputStream(new File("audios\\departure_for_space.wav").getAbsoluteFile());
            clip_fase = AudioSystem.getClip();
            clip_fase.open(audioInputStream_03); 
                                  
        } catch (Exception ex) {
            System.out.println("Erro ao executar SOM!");
            ex.printStackTrace();               
        } 
    }
    
    //Afirmação 01
    protected boolean estaTocandoAudioEnergiaMedia(){
        return clip_energia_tiro_medio.isRunning() || clip_energia_tiro_medio.isActive();
    }

    //Afirmação 02
    protected boolean estaTocandoAudioEnergiaForte(){
        return clip_energia_tiro_forte.isRunning() || clip_energia_tiro_forte.isActive();
    } 
    
    //Afirmação 03
    protected boolean estaEnergiaMaximaCarregada(){
        return var_aux_contador_energia == var_aux_limite_maximo_tiro_forte;
    } 

    //Afirmação 04
    protected boolean estaEnergiaMediaCarregada(){
        return var_aux_contador_energia > var_aux_limite_minimo_tiro_medio && var_aux_contador_energia < var_aux_limite_maximo_tiro_forte;
    }     

    //Afirmação 05
    protected boolean estaEnergiaBaixaCarregada(){
        return var_aux_contador_energia <= var_aux_limite_minimo_tiro_medio;
    }   
    
    //Afirmação 06
    protected boolean estaEnergiaMediaDescarregada(){
        return (this.estaTocandoAudioEnergiaMedia() && var_aux_contador_energia == 0);
    }     

    //Afirmação 07
    protected boolean estaEnergiaForteDescarregada(){
        return (this.estaTocandoAudioEnergiaForte() && var_aux_contador_energia == 0);
    }      

    //Afirmação 08
    public boolean estaTocandoCourseClear(){
        return clip_course_clear.isRunning() || clip_course_clear.isActive();
    }

    //Afirmação 09
    public boolean estaTocandoGameOver(){
        return clip_game_over.isRunning() || clip_game_over.isActive();
    }    
    
    
    public void recebeContadorEnergia(int contador_energia_carregada){
        
        this.var_aux_contador_energia = contador_energia_carregada;
                     
        if(contador_energia_carregada == 0 && this.estaTocandoAudioEnergiaMedia()){
            this.silenciaEnergiaCarregandoTiroMedio();
        }     
        
        if(contador_energia_carregada == 0 && this.estaTocandoAudioEnergiaForte()){
            this.silenciaEnergiaCarregandoTiroForte();
        }

        if(!this.estaTocandoAudioEnergiaMedia() && this.estaEnergiaMediaCarregada()){
            this.tocaEnergiaCarregandoTiroMedio();            
        }  

        if(!this.estaTocandoAudioEnergiaForte()&& this.estaEnergiaMaximaCarregada()){
            this.silenciaEnergiaCarregandoTiroMedio();
            this.tocaEnergiaCarregandoTiroForte();            
        }  

    }    
    
    
    public void tocaEnergiaCarregandoTiroMedio(){
            try {
                clip_energia_tiro_medio.loop(-1);                
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
 
    }    

    public void tocaEnergiaCarregandoTiroForte(){
            try {
                clip_energia_tiro_forte.loop(-1);                
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
 
    }     

    public void silenciaEnergiaCarregandoTiroMedio(){
            try {
                clip_energia_tiro_medio.stop();                
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
 
    }    

    public void silenciaEnergiaCarregandoTiroForte(){
            try {
                clip_energia_tiro_forte.stop();                
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
 
    }  
    
    public void tocaFase(){
            try {
                clip_fase.loop(-1);                      
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
    }

    public void silenciaFase(){
            try {
                clip_fase.stop();                      
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
    }    
    
    public void tocaTiroSimples(){
        try {
            AudioInputStream audioInputStream_04 = AudioSystem.getAudioInputStream(new File("audios\\laser4.wav").getAbsoluteFile());
            clip_tiro_simples = AudioSystem.getClip();
            clip_tiro_simples.open(audioInputStream_04);                 
            clip_tiro_simples.start();
        } catch (Exception ex) {
            System.out.println("Erro ao executar SOM!");                
        }   
    }

    public void tocaTiroMedio(){
        try {
            AudioInputStream audioInputStream_05 = AudioSystem.getAudioInputStream(new File("audios\\laser7.wav").getAbsoluteFile());
            clip_tiro_medio = AudioSystem.getClip();
            clip_tiro_medio.open(audioInputStream_05);              
            clip_tiro_medio.start();
        } catch (Exception ex) {
            System.out.println("Erro ao executar SOM!");                
        }            
    }
    
    public void tocaTiroForte(){
        try {
            AudioInputStream audioInputStream_06 = AudioSystem.getAudioInputStream(new File("audios\\laser8.wav").getAbsoluteFile());
            clip_tiro_forte = AudioSystem.getClip();
            clip_tiro_forte.open(audioInputStream_06);               
            clip_tiro_forte.start();
        } catch (Exception ex) {
            System.out.println("Erro ao executar SOM!");                
        }            
    }

    public void tocaNaveDestruida(){
        try {
            AudioInputStream audioInputStream_07 = AudioSystem.getAudioInputStream(new File("audios\\nave_destruida.wav").getAbsoluteFile());
            clip_nave_destruida = AudioSystem.getClip();
            clip_nave_destruida.open(audioInputStream_07);              
            clip_nave_destruida.start();
        } catch (Exception ex) {
            System.out.println("Erro ao executar SOM!");                
        }         
            
        this.silenciaFase();
        this.silenciaEnergiaCarregandoTiroMedio();
        this.silenciaEnergiaCarregandoTiroForte();
        
    }

    public void tocaInimigoDestruido(){
            try {
                AudioInputStream audioInputStream_08 = AudioSystem.getAudioInputStream(new File("audios\\inimigo_destruido.wav").getAbsoluteFile());
                clip_inimigo_destruido = AudioSystem.getClip();
                clip_inimigo_destruido.open(audioInputStream_08);                  
                clip_inimigo_destruido.start();                
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
    }    

    public void tocaCourseClear(){
            try {
                AudioInputStream audioInputStream_08 = AudioSystem.getAudioInputStream(new File("audios\\course_clear.wav").getAbsoluteFile());
                clip_course_clear = AudioSystem.getClip();
                clip_course_clear.open(audioInputStream_08);                  
                clip_course_clear.start();                
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
    }     

    public void tocaGameOver(){
            try {
                AudioInputStream audioInputStream_08 = AudioSystem.getAudioInputStream(new File("audios\\game_over.wav").getAbsoluteFile());
                clip_game_over = AudioSystem.getClip();
                clip_game_over.open(audioInputStream_08);                  
                clip_game_over.start();                
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
    } 

    public void tocaJogoFinalizado(){
            try {
                AudioInputStream audioInputStream_08 = AudioSystem.getAudioInputStream(new File("audios\\castle_clear.wav").getAbsoluteFile());
                clip_jogo_finalizado = AudioSystem.getClip();
                clip_jogo_finalizado.open(audioInputStream_08);                  
                clip_jogo_finalizado.start();                
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
    } 
    public void tocaAberturaJogo(){
            try {
                AudioInputStream audioInputStream_08 = AudioSystem.getAudioInputStream(new File("audios\\abertura.wav").getAbsoluteFile());
                clip_jogo_abertura = AudioSystem.getClip();
                clip_jogo_abertura.open(audioInputStream_08);                  
                clip_jogo_abertura.start();                
            } catch (Exception ex) {
                System.out.println("Erro ao executar SOM!");                
            }     
    } 
}   
