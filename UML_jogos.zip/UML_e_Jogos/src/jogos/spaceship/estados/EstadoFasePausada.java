/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.estados;

import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.fase.FaseGenerica;

/**
 *
 * @author Heriberto
 */
public class EstadoFasePausada extends Estado{

    public EstadoFasePausada(Jogo jogo, FaseGenerica fase, ChipGrafico chipGrafico, ChipSom chipSom) {
        super(jogo, fase, chipGrafico, chipSom);
    }

    @Override
    public void executaCiclo() {
        if(this.jogo.startPressionado()){
            this.jogo.vaiParaEstado(new EstadoExecutandoFase(jogo, fase, chipGrafico, chipSom));
        }  
        System.out.println("Fase pausada.");
    }

    @Override
    public void desenha() {
        //Não desenha nada
        //Tela exibe o último desenho da fase.
    }

    @Override
    public void tocaAudio() {
        //Não toca nada
    }
    
}
