/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.estados;

import console.controles.ControleGenerico;
import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.fase.FaseGenerica;

/**
 *
 * @author Heriberto
 */
public abstract class Estado {
    Jogo jogo;
    FaseGenerica fase;
    ChipGrafico chipGrafico;
    ChipSom chipSom;
    
    private boolean botao_start_pressionado;
    private boolean botao_start_liberado;
    private boolean comando_start_recebido;

    /**
     * Context passes itself through the state constructor. This may help a
     * state to fetch some useful context data if needed.
     */
    Estado(Jogo jogo, FaseGenerica fase, ChipGrafico chipGrafico, ChipSom chipSom) {
        this.jogo = jogo;
        this.chipGrafico = chipGrafico;
        this.chipSom = chipSom;
        this.fase = fase;
        
        this.botao_start_pressionado = false;
        this.botao_start_liberado = false;
        this.comando_start_recebido = false;
    }
    
    /*
    public boolean startPressionado(){
        
        if(this.jogo.getComando().contains(ControleGenerico.start)){
            this.botao_start_pressionado = true;
        }
        else{                  
            if(this.botao_start_pressionado){
                this.botao_start_liberado = true;
            }
        }
        
        if(!this.comando_start_recebido){
            if(this.botao_start_pressionado && this.botao_start_liberado){
                this.comando_start_recebido = true;
            }
        }
        else{
            this.botao_start_pressionado = false;
            this.botao_start_liberado = false;
            this.comando_start_recebido = false;
        }        
        
        return this.comando_start_recebido;        
    }
    */
    public abstract void executaCiclo();
    public abstract void desenha();
    public abstract void tocaAudio();    
}
