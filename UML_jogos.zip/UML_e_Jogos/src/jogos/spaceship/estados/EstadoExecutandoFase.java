/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.estados;

import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.fase.FaseGenerica;

/**
 *
 * @author Heriberto
 */
public class EstadoExecutandoFase extends Estado{

    public EstadoExecutandoFase(Jogo jogo, FaseGenerica fase, ChipGrafico chipGrafico, ChipSom chipSom) {
        super(jogo, fase, chipGrafico, chipSom);
    }

    @Override
    public void executaCiclo() {
        if(this.jogo.startPressionado()){
            this.jogo.vaiParaEstado(new EstadoFasePausada(jogo, fase, chipGrafico, chipSom));
        }
        if(this.fase.isOndaCoronasDerrotada()){
            this.jogo.vaiParaEstado(new EstadoFaseFinalizada(jogo, fase, chipGrafico, chipSom));
        }
        if(this.fase.isNaveAbatida()){
            this.jogo.vaiParaEstado(new EstadoGameOver(jogo, fase, chipGrafico, chipSom));
        }
        this.fase.recebeComando(this.jogo.getComando());
        this.fase.executaCiclo();
        System.out.println("Executando fase.");
    }

    @Override
    public void desenha() {
        this.fase.desenha();
    }

    @Override
    public void tocaAudio() {
        this.fase.tocaAudio();
    }
    
}
