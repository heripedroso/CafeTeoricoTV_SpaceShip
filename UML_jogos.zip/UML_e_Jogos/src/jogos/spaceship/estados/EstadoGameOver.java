/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.estados;

import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.fase.FaseGenerica;

/**
 *
 * @author Heriberto
 */
public class EstadoGameOver extends Estado{

    private boolean gatilho_audio;
    public EstadoGameOver(Jogo jogo, FaseGenerica fase, ChipGrafico chipGrafico, ChipSom chipSom) {
        super(jogo, fase, chipGrafico, chipSom);
        this.gatilho_audio = true;
    }

    @Override
    public void executaCiclo() {
        //Não executa nada
        System.out.println("Game Over!");
    }

    @Override
    public void desenha() {
        this.chipGrafico.desenhaBackgroundGameOver();
    }

    @Override
    public void tocaAudio() {
        if(this.gatilho_audio){
            this.chipSom.tocaGameOver();
        }
        this.gatilho_audio = false;
    }
    
}
