/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.estados;

import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.fase.FaseGenerica;

/**
 *
 * @author Heriberto
 */
public class EstadoPressioneStartParaComecar extends Estado {
    
    private boolean gatilho_audio;

    public EstadoPressioneStartParaComecar(Jogo jogo, FaseGenerica fase, ChipGrafico chipGrafico, ChipSom chipSom) {
        super(jogo, fase, chipGrafico, chipSom);
        gatilho_audio = true;
    }

    @Override
    public void executaCiclo() {
        if(this.jogo.startPressionado()){            
            this.jogo.vaiParaEstado(new EstadoExecutandoFase(jogo, fase, chipGrafico, chipSom));
            this.fase.inicia();
        }  
        System.out.println("Aguardando START");
        
    }

    @Override
    public void desenha() {
        this.chipGrafico.desenhaBackgroundAguardandoStartParaComecar();  
    }

    @Override
    public void tocaAudio() {
        if(gatilho_audio){
            this.chipSom.tocaAberturaJogo();
        }
        gatilho_audio = false; 
    }
    
}
