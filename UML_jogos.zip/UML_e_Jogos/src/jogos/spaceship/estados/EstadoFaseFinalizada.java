/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.estados;

import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.fase.FaseGenerica;

/**
 *
 * @author Heriberto
 */
public class EstadoFaseFinalizada extends Estado{

    private boolean gatilho_audio;
    public EstadoFaseFinalizada(Jogo jogo, FaseGenerica fase, ChipGrafico chipGrafico, ChipSom chipSom) {
        super(jogo, fase, chipGrafico, chipSom);
        this.gatilho_audio = true;
    }

    private void delay(int ciclos){
        for(int i =0; i < ciclos; i++){
            //Laço para simular um delay.
        }
    }
    @Override
    public void executaCiclo() {
        System.out.println("Fase finalizada.");
        System.out.println("Tem próxima fase : " + this.jogo.temProximaFase());        
        if(this.jogo.temProximaFase()){
            if(!chipSom.estaTocandoCourseClear()){     
                this.fase = this.jogo.getProximaFase();
                this.fase.inicia();
                this.jogo.vaiParaEstado(new EstadoExecutandoFase(jogo,this.fase, chipGrafico, chipSom));    
            }
        }
        else{
            this.jogo.vaiParaEstado(new EstadoJogoFinalizado(jogo, fase, chipGrafico, chipSom));
        }        
    }

    @Override
    public void desenha() {
        this.chipGrafico.desenhaBackgroundFaseFinalizada();
    }

    @Override
    public void tocaAudio() {
        this.chipSom.silenciaFase();
        if(this.gatilho_audio && this.jogo.temProximaFase()){
            this.chipSom.tocaCourseClear();            
        }
        this.gatilho_audio = false;
    }
    
}
