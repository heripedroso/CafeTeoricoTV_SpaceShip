/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.fase.FaseBuilder;
import jogos.spaceship.fase.FaseGenerica;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;

/**
 *
 * @author Heriberto
 */
public class Cartucho {
    
    private FaseBuilder faseBuilder;
    private Jogo jogo;
        
    public Cartucho(){
        
        faseBuilder = new FaseBuilder();
        
        ChipGrafico chipGrafico = new ChipGrafico();
        ChipSom chipSom = new ChipSom();
        NaveEspacialGenerica nave = new NaveEspacialRaptor(chipGrafico, chipSom);
        this.jogo = new Jogo(nave,chipGrafico,chipSom);      
        
        FaseGenerica primeira_fase = faseBuilder
                                        .atributo01_insereNave(nave)
                                        .atributo02_setPassoNave(6)
                                        .atributo03_setQtdeCoronas(15)
                                        .atributo04_setPassoCoronas(4)
                                        .atributo05_setQtdeCiclosEntreCoronasGerados(100)
                                        .atributo06_insereChipGrafico(chipGrafico)
                                        .atributo07_insereChipGrafico(chipSom)
                                        .atributo08_setMovimentoCoronasAvancam()
                                        .produz();
        FaseGenerica segunda_fase = faseBuilder
                                        .atributo01_insereNave(nave)
                                        .atributo02_setPassoNave(6)
                                        .atributo03_setQtdeCoronas(30)
                                        .atributo04_setPassoCoronas(4)
                                        .atributo05_setQtdeCiclosEntreCoronasGerados(50)
                                        .atributo06_insereChipGrafico(chipGrafico)
                                        .atributo07_insereChipGrafico(chipSom)
                                        .atributo08_setMovimentoCoronasPerseguemNave()
                                        .produz();
        jogo.addFase(primeira_fase);
        jogo.addFase(segunda_fase);

    }
    
    public Jogo getJogo(){
        return this.jogo;
    }
}
