/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship;

import jogos.spaceship.estados.EstadoPressioneStartParaComecar;
import jogos.spaceship.estados.EstadoJogoFinalizado;
import jogos.spaceship.estados.EstadoFaseFinalizada;
import jogos.spaceship.estados.EstadoExecutandoFase;
import jogos.spaceship.estados.Estado;
import jogos.spaceship.estados.EstadoGameOver;
import jogos.spaceship.estados.EstadoFasePausada;
import jogos.spaceship.fase.FaseGenerica;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.nave.NaveEspacialGenerica;
import console.controles.ControleGenerico;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;


/**
 *
 * @author Heriberto
 */
public class Jogo {
    
    private ChipGrafico chipGrafico;
    private ChipSom chipSom;
   
    private NaveEspacialGenerica nave;
    
    private String comando_controle_01;
    
    private boolean iniciado;
    private boolean pausado;
    private boolean finalizado;
    private boolean gameOver;
    
    private boolean telaConectada;
    private boolean pincelConectado;
    
    private boolean botao_start_pressionado;
    private boolean botao_start_liberado;
    private boolean comando_start_recebido;     
    
    private List<FaseGenerica> lista_fases = new ArrayList();
    private FaseGenerica fase_atual;
    private int contador_fases; 
    
    private Estado estado;
    
    
    public Jogo(NaveEspacialGenerica nave, ChipGrafico chipGrafico, ChipSom chipSom){
        this.chipSom = chipSom;
        this.chipGrafico = chipGrafico;       
                
        this.nave = nave;  
        this.nave.setPasso(6);
        
        this.telaConectada = false;
        this.pincelConectado = false;
        
        this.comando_controle_01 = "";
        this.contador_fases = 0;                    
    } 
    
    public void conectaTela(JPanel tela) {
        if(tela != null){            
            chipGrafico.conectaTela(tela);
        }
    }    
    
    public void conectaPincel(Graphics pincel) {
        if(pincel != null){                            
            chipGrafico.conectaPincel(pincel);
        }
    }  
    
    public void recebeComando(String comando){               
        this.comando_controle_01 = comando;     
    }         
    
    public void addFase(FaseGenerica fase){                   
        if(this.lista_fases.isEmpty()){
            this.fase_atual = fase; 
            this.contador_fases = 1;
        }
        this.lista_fases.add(fase); 
    }

    public boolean temProximaFase(){
        return this.contador_fases < this.lista_fases.size();
    }    

    public FaseGenerica getProximaFase(){
        this.contador_fases += 1; 
        return this.lista_fases.get(this.contador_fases-1);            
    }
    
    public boolean startPressionado(){
        
        if(this.botao_start_pressionado && this.botao_start_liberado){
            this.botao_start_pressionado = false;
            this.botao_start_liberado = false;            
        }
        if(this.comando_controle_01.contains(ControleGenerico.start)){
            this.botao_start_pressionado = true;
        }
        else{                  
            if(this.botao_start_pressionado){
                this.botao_start_liberado = true;
            }
        }

        return this.botao_start_pressionado && this.botao_start_liberado;
    }     

    public void vaiParaEstado(Estado estado) {
        this.estado = estado;
    }
    
    public boolean isAguardandoStart(){
        return this.estado instanceof EstadoPressioneStartParaComecar;
    }

    public boolean isExecutandoFase(){
        return this.estado instanceof EstadoExecutandoFase;
    }
    
    public boolean isFasePausada(){
        return this.estado instanceof EstadoFasePausada;
    }

    public boolean isFaseFinalizada(){
        return this.estado instanceof EstadoFaseFinalizada;
    }

    public boolean isGameOver(){
        return this.estado instanceof EstadoGameOver;
    }
    
    public boolean isJogoFinalizado(){
        return this.estado instanceof EstadoJogoFinalizado;
    }   
    
    public String getComando(){
        return this.comando_controle_01;
    }
    
    
    public void executaCiclo(){      
        this.estado.executaCiclo();
    }     
    
    public void desenha(){                               
        this.estado.desenha();        
    }
    
    public void tocaAudios(){  
        this.estado.tocaAudio(); 
    }        
}
