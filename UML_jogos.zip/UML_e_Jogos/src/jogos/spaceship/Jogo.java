/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship;

import jogos.spaceship.fase.FaseGenerica;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.nave.NaveEspacialGenerica;
import console.Tela;
import console.controles.ControleGenerico;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Heriberto
 */
public class Jogo {
    
    private ChipGrafico chipGrafico;
    private ChipSom chipSom;
   
    private NaveEspacialGenerica nave;
    
    private String comando_controle_01;
    
    private boolean iniciado;
    private boolean pausado;
    private boolean finalizado;
    private boolean gameOver;
    
    private boolean telaConectada;
    private boolean pincelConectado;
    
    private boolean botao_start_pressionado;
    private boolean botao_start_liberado;
    private boolean comando_start_recebido;     
    
    private List<FaseGenerica> lista_fases = new ArrayList();
    private FaseGenerica fase_atual;
    private int contador_fases; 
    
    
    public Jogo(NaveEspacialGenerica nave, ChipGrafico chipGrafico, ChipSom chipSom){
        this.chipSom = chipSom;
        this.chipGrafico = chipGrafico;       
                
        this.nave = nave;  
        this.nave.setPasso(6);
        
        this.vaiParaEstadoAguardandoStart();
        
        this.telaConectada = false;
        this.pincelConectado = false;
        
        this.comando_controle_01 = "";
        this.contador_fases = 0;    
        
    }
   
    public void conectaTela(Tela tela) {
        if(tela != null){            
            chipGrafico.conectaTela(tela);
        }
    }    
    
    public void conectaPincel(Graphics pincel) {
        if(pincel != null){                            
            chipGrafico.conectaPincel(pincel);
        }
    }  
    
    public void recebeComando(String comando){               
        this.comando_controle_01 = comando;     
    }         
    
    public void addFase(FaseGenerica fase){        
        this.lista_fases.add(fase);       
        if(this.lista_fases.size() == 1){
            this.fase_atual = this.lista_fases.get(0);
        }
    }

    public void avancaProximaFase(){
        if((this.contador_fases) < this.lista_fases.size()){
            this.contador_fases += 1;
            this.fase_atual = this.lista_fases.get(this.contador_fases-1);
        }
        else{
            this.vaiParaEstadoFinalizado();
        }                
    }
    
    public boolean startPressionado(){
        
        if(this.comando_controle_01.contains(ControleGenerico.start)){
            this.botao_start_pressionado = true;
        }
        else{                  
            if(this.botao_start_pressionado){
                this.botao_start_liberado = true;
            }
        }
        
        if(!this.comando_start_recebido){
            if(this.botao_start_pressionado && this.botao_start_liberado){
                this.comando_start_recebido = true;
            }
        }
        else{
            this.botao_start_pressionado = false;
            this.botao_start_liberado = false;
            this.comando_start_recebido = false;
        }        
        
        return this.comando_start_recebido;
    }
    
    public void vaiParaEstadoAguardandoStart(){        
        this.iniciado = false;   
        this.pausado = false;
        this.finalizado = false;
        this.gameOver = false;                
    }
    
    public void vaiParaEstadoIniciado(){        
        this.iniciado = true;   
        this.pausado = false;
        this.finalizado = false;
        this.gameOver = false;        
    }

    public void vaiParaEstadoPausado(){        
        this.iniciado = true;                 
        this.pausado = true;
        this.finalizado = false;
        this.gameOver = false;        
    }
    
    public void vaiParaEstadoFinalizado(){
       this.iniciado = true;
       this.pausado = false;
       this.finalizado = true;
       this.gameOver = false;
    }        
    
    public void vaiParaEstadoGameOver(){
       this.iniciado = true;
       this.pausado = false;
       this.finalizado = false;
       this.gameOver = true;   
    }       

    public boolean isAguardandoStart(){ 
        return this.iniciado == false && this.pausado == false && this.finalizado == false && this.gameOver == false;
    }
    
    public boolean isIniciado(){ 
        return this.iniciado == true && this.pausado == false && this.finalizado == false && this.gameOver == false;
    }

    public boolean isPausado(){ 
        return this.iniciado == true && this.pausado == true && this.finalizado == false && this.gameOver == false;
    }

    public boolean isFinalizado(){ 
        return this.iniciado == true && this.pausado == false && this.finalizado == true && this.gameOver == false;
    }    

    public boolean isGameOver(){ 
        return this.iniciado == true && this.pausado == false && this.finalizado == false && this.gameOver == true;
    }    
    
    public void alternaEstados(){
        if(this.startPressionado()){
            if (this.isAguardandoStart()){
                this.vaiParaEstadoIniciado();
                this.fase_atual.inicia();
                System.out.println("Jogo Iniciado");
            }  
            else if (this.isIniciado()){
                this.vaiParaEstadoPausado();
                System.out.println("Jogo Pausado");
            }          
            else if (this.isPausado()){
                this.vaiParaEstadoIniciado();
                System.out.println("Jogo Iniciado");
            }  
            else if (this.isGameOver()){
                //
            }  
            else{
                //
            }
        }
        
        if (this.fase_atual.isGameOver()){
            this.vaiParaEstadoGameOver();
            System.out.println("Game Over!");
        }
        
        if(this.fase_atual.isFinalizadaComSucesso()){
           if(this.lista_fases.iterator().hasNext()){
               this.vaiParaEstadoAguardandoStart();
               this.avancaProximaFase();               
           }
           else{
               this.vaiParaEstadoFinalizado();
           }
        }        
    }            

    public void confirmaTelaConectada(){
        telaConectada = true;
    }
    
    public void confirmaPincelConectado(){
        pincelConectado = true;
    }
    
    public boolean isTelaConectada() {
        return telaConectada;
    }

    public boolean isPincelConectado() {
        return pincelConectado;
    }
    
    public ChipGrafico getChipGrafico() {
        return chipGrafico;
    }

    public ChipSom getChipSom() {
        return chipSom;
    }

    public void executaCiclo(){       
        
        this.alternaEstados();

        if(this.isIniciado()){
            this.fase_atual.recebeComando(comando_controle_01);
            this.fase_atual.executaCiclo();             
        }    
    }     
    
    public void enviaVideo(){                               
        
        if(this.isAguardandoStart()){
            this.chipGrafico.desenhaBackGroundProximaFase();
        }
        if(this.isIniciado()){
            this.fase_atual.desenha();            
        }
        if(this.isFinalizado()){
            chipGrafico.desenhaBackGroundJogoFinalizado();
        }
        if(this.isPausado()){
            //
        }
        if(this.isGameOver()){

        }
        
    }
    
    public void tocaAudios(){  
        if(this.isIniciado()){
            this.fase_atual.tocaAudio();
        }
        if(this.isFinalizado()){
            //
        }
        if(this.isPausado()){
            //
        }
        if(this.isGameOver()){
            //
        }     
 
    }     
}
