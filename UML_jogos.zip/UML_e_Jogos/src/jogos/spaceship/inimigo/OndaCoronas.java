/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.inimigo;

import jogos.spaceship.nave.NaveEspacialGenerica;
import java.util.ArrayList;
import java.util.List;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.fase.FaseGenerica;
import jogos.spaceship.movimento.MovimentoGenerico;
import jogos.spaceship.movimento.corona.MovimentoCoronaAvanca;
import jogos.spaceship.movimento.corona.MovimentoCoronaPersegue;

/**
 *
 * @author Heriberto
 */
public class OndaCoronas {

    private List<InimigoGenerico> coronas;    
    private int contador_ciclos;
    private int ciclosDelay;
    
    private int contador_coronas;
    private int qtdeCoronas;
    
    private int passoCoronas;

    private ChipGrafico ref_chipGrafico;
    private ChipSom ref_chipSom;
    
    private MovimentoGenerico movimento;
    private NaveEspacialGenerica ref_nave;
    private FaseGenerica ref_fase;
    
    public OndaCoronas(int qtdeCoronas, int ciclosDelay, int passoCoronas, NaveEspacialGenerica nave, ChipGrafico chipGrafico, MovimentoGenerico movimento) {
        this.contador_ciclos = 0;        
        this.ciclosDelay = ciclosDelay;  
        this.contador_coronas = 0;
        this.qtdeCoronas = qtdeCoronas;
        this.passoCoronas = passoCoronas; //velocidade de deslocamento dos coronas
        this.ref_chipGrafico = chipGrafico;
        this.ref_nave = nave;
        this.coronas = new ArrayList();  
        this.movimento = movimento;
    }           

    public void setMovimentoPersegue(){
        this.movimento = new MovimentoCoronaPersegue(this.passoCoronas,this.ref_nave,this.ref_chipGrafico);
    }
    
    public void geraCorona(){
        contador_ciclos += 1;
        if( contador_ciclos == ciclosDelay){  
            contador_ciclos = 0;   
            if(contador_coronas < qtdeCoronas){
                contador_coronas += 1;
                if( this.movimento instanceof MovimentoCoronaAvanca ){
                    this.movimento = new MovimentoCoronaAvanca(this.passoCoronas, this.ref_chipGrafico);
                }
                if( this.movimento instanceof MovimentoCoronaPersegue ){
                    this.movimento = new MovimentoCoronaPersegue(this.passoCoronas, this.ref_nave, this.ref_chipGrafico);
                }
                this.coronas.add(new InimigoCorona(this.ref_nave,this.movimento,this.ref_chipGrafico));   
            }
        }    
    }
    
    public void movimentaCoronas(){        
        if(!this.coronas.isEmpty()){
            for(int i=0;i<this.coronas.size();i++){
                this.coronas.get(i).seMovimenta();
            }    
        }      
    }

    public void desenhaCoronas(){
        if(!this.coronas.isEmpty()){
            for(int i=0;i<this.coronas.size();i++){
                this.coronas.get(i).desenha();
            }    
        }
    }

    public void apagaCoronas(){
        if(!this.coronas.isEmpty()){
            for(int i=0;i<this.coronas.size();i++){
                if(!this.coronas.get(i).isVisivel()){
                    this.coronas.remove(i);
                }  
            }    
        }                    
    }
    
    public void executaCiclo(){        
        //this.geraCorona();
        //this.apagaCoronas();
        this.geraCorona();
        this.movimentaCoronas();
        //this.desenhaCoronas();
    }
    
    public boolean isTodosOsCoronasForamGerados(){
        return this.contador_coronas == this.qtdeCoronas;
    }

    public boolean estahFinalizada(){
        if(this.isTodosOsCoronasForamGerados()){
            for(int i = 0; i < this.coronas.size()-1; i++){
                if(!this.coronas.get(i).isVisivel()){
                    this.coronas.remove(i);
                }
            }        
        }
        return this.isTodosOsCoronasForamGerados() && this.coronas.isEmpty();
    }
    
    public List<InimigoGenerico> getCoronas() {
        return coronas;
    }

    public void setCiclosDelay(int ciclosDelay) {
        this.ciclosDelay = ciclosDelay;
    }

    public void setQtdeCoronas(int qtdeCoronas) {
        this.qtdeCoronas = qtdeCoronas;
    }

    public void setPassoCoronas(int passoCoronas) {
        this.passoCoronas = passoCoronas;
    }
    
}
