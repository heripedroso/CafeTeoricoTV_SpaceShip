/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.inimigo;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.movimento.MovimentoGenerico;
import jogos.spaceship.movimento.MovimentoCoronaAvanca;
import jogos.spaceship.movimento.MovimentoCoronaPersegue;
import jogos.spaceship.nave.NaveEspacialGenerica;

/**
 *
 * @author Heriberto
 */
public class OndaCoronasBuilder {
    
    private OndaCoronas onda;
    private ChipGrafico chipGrafico;
    private NaveEspacialGenerica nave;
    private MovimentoGenerico movimento;
    private int qtdeCoronas;
    private int ciclosDelay;
    private int passo;        
    
    public OndaCoronasBuilder atributo01_conectaChipGrafico(ChipGrafico chip){
        this.chipGrafico = chip;
        return this;
    }

    public OndaCoronasBuilder atributo02_setNaveInimiga(NaveEspacialGenerica nave){
        this.nave = nave;
        return this;
    }    
    
    public OndaCoronasBuilder atributo03_seQtdeCoronas(int qtde){
        this.qtdeCoronas = qtde;   
        return this;
    }

    public OndaCoronasBuilder atributo04_setPassoCoronas(int passo){
        this.passo = passo;      
        return this;
    } 
    
    public OndaCoronasBuilder atributo05_setQtdeCiclosEntreCoronasGerados(int ciclos){
        this.ciclosDelay = ciclos;    
        return this;
    }    
     
    public OndaCoronasBuilder atributo06_setMovimentoCoronaAvanca(){
        this.movimento = new MovimentoCoronaAvanca(this.passo,this.chipGrafico);    
        return this;
    }  
    
    public OndaCoronasBuilder atributo06_setMovimentoCoronaPersegueNave(){
        this.movimento = new MovimentoCoronaPersegue(this.passo,this.nave,this.chipGrafico);    
        return this;
    }  
    
    public OndaCoronas produz(){
        return new OndaCoronas(this.qtdeCoronas, this.ciclosDelay, this.passo, this.nave, this.chipGrafico, this.movimento);
    }
}
