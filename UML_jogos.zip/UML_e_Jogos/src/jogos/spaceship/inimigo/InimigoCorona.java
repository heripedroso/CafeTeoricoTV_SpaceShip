/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.inimigo;

import jogos.spaceship.movimento.MovimentoGenerico;
import java.util.Random;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.nave.NaveEspacialGenerica;

/**
 *
 * @author Heriberto
 */
public class InimigoCorona implements InimigoGenerico{

    private int x;
    private int y;
    private int largura;
    private int altura;
    private int velocidade_deslocamento;
    
    private boolean visivel;
    
    private ChipGrafico ref_chip_grafico;
    private ChipSom ref_chipSom;
    private NaveEspacialGenerica ref_nave;
    
    private MovimentoGenerico movimento;
    
    public InimigoCorona(NaveEspacialGenerica nave, MovimentoGenerico movimento, ChipGrafico chipGrafico){
        this.x = 1024;
        this.y = new Random().nextInt(510);     
        this.ref_nave = nave;
        this.movimento = movimento;    
        this.ref_chip_grafico = chipGrafico;
    }   
    
    @Override
    public int getX() {
        return movimento.getX();
    }

    @Override
    public int getY() {
        return movimento.getY();
    }

    @Override
    public int getLargura() {
        return this.ref_chip_grafico.getLargura_corona();
    }

    @Override
    public int getAltura() {
        return this.ref_chip_grafico.getAltura_corona();
    }

    @Override
    public void seMovimenta() {
        this.movimento.movimenta();    
    }        

    @Override
    public boolean isVisivel() {
        return movimento.isVisivel();
    }

    @Override
    public void desenha() {
        this.movimento.desenha();
    }
    
}