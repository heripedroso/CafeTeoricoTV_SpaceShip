/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.fase;

import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.colisao.Colisao;
import jogos.spaceship.inimigo.OndaCoronas;
import jogos.spaceship.inimigo.OndaCoronasBuilder;
import jogos.spaceship.nave.NaveEspacialGenerica;

/**
 *
 * @author Heriberto
 */
public class FaseBuilder {
    
    private OndaCoronas onda;
    OndaCoronasBuilder ondaBuilder;
    private NaveEspacialGenerica nave;
    private ChipGrafico chipGrafico;
    private ChipSom chipSom;
    private Colisao colisao;
    private int qtdeCoronas;
    private int ciclosEntreCoronasGerados;
    private int passoCoronas;
    
    
    public FaseBuilder(){
        ondaBuilder = new OndaCoronasBuilder(); 
    }      

    public FaseBuilder atributo01_insereNave(NaveEspacialGenerica nave){
        this.nave = nave;
        return this;
    }    
    
    public FaseBuilder atributo02_setPassoNave(int passo){
        this.nave.setPasso(passo);
        return this;
    }
    
    public FaseBuilder atributo03_setQtdeCoronas(int qtde){
        this.qtdeCoronas = qtde;
        return this;
    } 
    
    public FaseBuilder atributo04_setPassoCoronas(int passo){
        this.passoCoronas = passo;
        return this;
    }
    
    public FaseBuilder atributo05_setQtdeCiclosEntreCoronasGerados(int ciclos){
        this.ciclosEntreCoronasGerados = ciclos;
        return this;
    } 

    public FaseBuilder atributo06_insereChipGrafico(ChipGrafico chipGrafico){
        this.chipGrafico = chipGrafico;
        return this;
    }     

    public FaseBuilder atributo07_insereChipGrafico(ChipSom chipSom){
        this.chipSom = chipSom;
        return this;
    } 
    
    public FaseBuilder atributo08_setMovimentoCoronasAvancam(){  
        this.onda = ondaBuilder
                                .atributo01_conectaChipGrafico(this.chipGrafico)
                                .atributo02_setNaveInimiga(this.nave)
                                .atributo03_seQtdeCoronas(this.qtdeCoronas)
                                .atributo04_setPassoCoronas(this.passoCoronas)
                                .atributo05_setQtdeCiclosEntreCoronasGerados(this.ciclosEntreCoronasGerados)
                                .atributo06_setMovimentoCoronaAvanca()
                                .produz();  
        return this;
    } 
    
    public FaseBuilder atributo08_setMovimentoCoronasPerseguemNave(){
        this.onda = ondaBuilder
                                .atributo01_conectaChipGrafico(this.chipGrafico)
                                .atributo02_setNaveInimiga(this.nave)
                                .atributo03_seQtdeCoronas(this.qtdeCoronas)
                                .atributo04_setPassoCoronas(this.passoCoronas)
                                .atributo05_setQtdeCiclosEntreCoronasGerados(this.ciclosEntreCoronasGerados)
                                .atributo06_setMovimentoCoronaPersegueNave()
                                .produz();  
        return this;
    } 

    public FaseGenerica produz(){   
        FaseGenerica fase = new Fase(this.nave, this.onda, new Colisao(this.chipGrafico,this.chipSom), chipGrafico,chipSom);
        return fase;
    }
    
}
