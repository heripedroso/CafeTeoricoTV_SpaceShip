/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.fase;

import jogos.spaceship.colisao.Colisao;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.inimigo.OndaCoronas;
import jogos.spaceship.nave.NaveEspacialGenerica;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import jogos.spaceship.Jogo;
import jogos.spaceship.inimigo.OndaCoronasBuilder;

/**
 *
 * @author Heriberto
 */
public class Fase implements FaseGenerica{

    private String comandoNave_01;
    
    private FaseGenerica ref_proximaFase;
    
    private Jogo ref_jogo;

    private NaveEspacialGenerica nave_01; 
    
    private List<OndaCoronas> ondasCoronas;           
    
    private boolean fase_iniciada;
    private boolean gatilho_tocaAudioFase;
    
    private Colisao colisao;
    
    private ChipGrafico ref_chip_grafico;
    private ChipSom ref_chipSom_01;
    
    private OndaCoronas ondaCoronas;
    private OndaCoronasBuilder ondaCoronasBuilder;

    public Fase(NaveEspacialGenerica nave, OndaCoronas onda, Colisao colisao, ChipGrafico chipGrafico, ChipSom chipSom){    
                
        this.fase_iniciada = false;
        
        this.nave_01 = nave; 
        this.ref_chip_grafico = chipGrafico;
        this.ref_chipSom_01 = chipSom;                                                                           
        this.colisao = colisao;   
        this.ondaCoronas = onda;
        gatilho_tocaAudioFase = false;    
    }    
    
    
    @Override
    public void recebeComando(String comando) {        
        this.comandoNave_01 = comando;
    }    
    
    @Override
    public void inicia() {
        this.gatilho_tocaAudioFase = true;   
        this.fase_iniciada = true;
        this.comandoNave_01 = "";
        this.nave_01.setPosicaoInicial();
        this.nave_01.setAbatida(false);  
        this.nave_01.getRajada_tiros().clear(); // Limpa a tela
    }       
    
    @Override
    public boolean isIniciada() {
        return this.fase_iniciada;
    } 
    
    @Override
    public boolean isOndaCoronasDerrotada() {
        return this.ondaCoronas.estahFinalizada();
    }         

    @Override
    public boolean isNaveAbatida(){
        return this.nave_01.isAbatida();
    } 
    
    public void verificaColisao(){    
        // ----------------- Onda coronas ------------------- //
        colisao.acertaTiro(nave_01.getRajada_tiros(), this.ondaCoronas.getCoronas());
        colisao.naveAbatida(nave_01, this.ondaCoronas.getCoronas());
        colisao.erraTiro(nave_01.getRajada_tiros());                  
    }
    
    @Override
    public void executaCiclo() {    
 
        this.nave_01.recebeComando(comandoNave_01);
        this.nave_01.executaCiclo();
        this.ondaCoronas.executaCiclo();        
        this.verificaColisao();           
    }           
    
    @Override
    public void desenha(){
         
        this.ref_chip_grafico.desenhaBackground();    

        this.nave_01.desenha();
        this.ondaCoronas.desenhaCoronas();  
        this.ondaCoronas.apagaCoronas();

        colisao.desenha();     
    }         
    
    @Override
    public void tocaAudio(){
        //  ------------------------ Toca tema da fase ------------------------//
        if(this.gatilho_tocaAudioFase){
            this.ref_chipSom_01.tocaFase();
            this.gatilho_tocaAudioFase = false;
        }

        if(this.isOndaCoronasDerrotada()){
            this.ref_chipSom_01.silenciaFase();
        }
        
        //  ------------------------ Toca audio tiros e energia acumulada ------------------------//
        try {            
            this.nave_01.tocaAudio();
        } catch (Throwable ex) {
            Logger.getLogger(Fase.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //  ------------------------ Toca audio inimigo destruído ------------------------//
        colisao.tocaAudio();
    
    }    
}
