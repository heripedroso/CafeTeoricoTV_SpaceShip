/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.fase;

import java.util.List;
import jogos.spaceship.Jogo;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.inimigo.InimigoGenerico;
import jogos.spaceship.inimigo.OndaCoronas;
import jogos.spaceship.nave.NaveEspacialGenerica;

/**
 *
 * @author Heriberto
 */
public interface FaseGenerica {
    public void recebeComando(String comando);    
    public void inicia();
    public boolean isIniciada();
    public boolean isFinalizadaComSucesso();    
    public boolean isGameOver();     
    public void executaCiclo();    
    public void desenha();
    public void tocaAudio();       
}
