/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.fase;

/**
 *
 * @author Heriberto
 */
public interface FaseGenerica {
    public void recebeComando(String comando);    
    public void inicia();
    public boolean isIniciada();  
    public void executaCiclo();    
    public void desenha();
    public void tocaAudio();  
    public boolean isNaveAbatida();
    public boolean isOndaCoronasDerrotada();
}
