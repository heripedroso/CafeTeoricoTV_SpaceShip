/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.movimento;

import jogos.spaceship.SomImagem.ChipGrafico;

/**
 *
 * @author Heriberto
 */
public interface MovimentoGenerico {

    public boolean xForaDoLimiteDireita() ;

    public void paraDireita();
    
    public boolean xForaDoLimiteEsquerda();

    public void paraEsquerda();
    
    public boolean yForaDoLimiteCima();

    public void paraCima();
    
    public boolean yForaDoLimiteBaixo();
    
    public void paraBaixo();

    public int getX();

    public int getY();

    public void setX(int x);

    public void setY(int y);

    public void setLimite_x(int limite_x);

    public void setLimite_y(int limite_y) ;
    
    public void setPasso(int passo);
    
    public void defineLimites();
    
    public boolean isVisivel();    
    
    public void movimenta();

    public void desenha();
}
