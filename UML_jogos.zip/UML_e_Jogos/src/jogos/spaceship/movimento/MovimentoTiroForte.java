package jogos.spaceship.movimento;

import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.movimento.MovimentoGenerico;

/**
 *
 * @author Heriberto
 */
public class MovimentoTiroForte implements MovimentoGenerico{

    private int x;
    private int y;
    private int passo;
    private int limite_x;
    private int limite_y;
    
    private ChipGrafico ref_chipGrafico;  

    public MovimentoTiroForte(int x, int y, int passo, ChipGrafico chipGrafico){
        this.x = x;
        this.y = y;
        this.passo = passo;
        this.ref_chipGrafico = chipGrafico;
        this.defineLimites();
    }           


    @Override
    public boolean xForaDoLimiteDireita() {
        return (x + passo) > limite_x;     
    }

    @Override
    public void paraDireita(){
        if (!this.xForaDoLimiteDireita())
            x = x + passo;  
        else
            x = limite_x; 
    }
    
    @Override
    public boolean xForaDoLimiteEsquerda() {
        return (x - passo) < 0; 
    }

    @Override
    public void paraEsquerda(){
        if (!this.xForaDoLimiteEsquerda())
            x = x - passo;   
        else
            x = 0; 
    }   
    
    @Override
    public boolean yForaDoLimiteCima() {
        return (y - passo) < 0; //Eixo Y invertido
    }

    @Override
    public void paraCima(){
        if (!this.yForaDoLimiteCima())
            y = y - passo;
        else
            y = 0; 
    }   
    
    @Override
    public boolean yForaDoLimiteBaixo() {
        return (y + passo) > limite_y; //Eixo Y invertido
    }    

    @Override
    public void paraBaixo(){
        if (!this.yForaDoLimiteBaixo())
            y = y + passo;
        else
            y = limite_y; 
    }
        
    @Override
    public int getX() {
        return x;
    }

    @Override    
    public int getY() {
        return y;
    }

    @Override
    public void setX(int x) {
        this.x = x;
    }

    @Override
    public void setY(int y) {
        this.y = y;
    }

    @Override
    public void setLimite_x(int limite_x) {
        this.limite_x = limite_x;
    }

    @Override
    public void setLimite_y(int limite_y) {
        this.limite_y = limite_y;
    }

    @Override
    public void setPasso(int passo){
        this.passo = passo;
    }
    
    @Override
    public void defineLimites() {
        this.setLimite_x(ref_chipGrafico.getLargura_imagem_fundo());
    }    
    
    @Override
    public void desenha() {
        ref_chipGrafico.desenhaTiroForte(this.getX(), this.getY());
    }
   
    @Override
    public void movimenta() {
        this.paraDireita();
    }

    @Override
    public boolean isVisivel() {
        return !this.xForaDoLimiteDireita();
    }
}
