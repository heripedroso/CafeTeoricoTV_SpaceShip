/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.spaceship.colisao;

import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.nave.canhao.tiro.TiroGenerico;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.inimigo.InimigoGenerico;
import java.awt.Rectangle;
import java.util.List;
import jogos.spaceship.SomImagem.ChipGrafico;

/**
 *
 * @author Heriberto
 */
public class Colisao {
    
    private Rectangle retangulo_tiro;
    private Rectangle retangulo_inimigo;
    private Rectangle retangulo_nave;
    
    private boolean inimigo_destruido;
    private boolean nave_destruida_audio;    
    private boolean nave_destruida_grafico;    
    
    private ChipSom ref_chipSom;
    private ChipGrafico ref_chipGrafico;
    
    private NaveEspacialGenerica nave;
    
    private int ajuste_colisao;
        
    public Colisao(ChipGrafico chipGrafico, ChipSom chipSom){
        inimigo_destruido = false;
        nave_destruida_audio = false;
        nave_destruida_grafico = false;
        this.ref_chipSom = chipSom;
        this.ref_chipGrafico = chipGrafico;
        this.ajuste_colisao = 15;
    }
    
    public void acertaTiro(List<TiroGenerico> tiros, List<InimigoGenerico> inimigos){
        
        this.inimigo_destruido = false;
        
        for(int i=0;i<tiros.size();i++){
            retangulo_tiro = new Rectangle(tiros.get(i).getX(), tiros.get(i).getY(), tiros.get(i).getLargura(), tiros.get(i).getAltura());
            
                for(int j=0;j<inimigos.size();j++){
                retangulo_inimigo = new Rectangle(inimigos.get(j).getX(), inimigos.get(j).getY(), inimigos.get(j).getLargura(), inimigos.get(j).getAltura());
            
                    if (retangulo_tiro.intersects(retangulo_inimigo)) {
                        tiros.remove(i);
                        inimigos.remove(j);       
                        this.inimigo_destruido = true;
                    }
                }                                                   
        }          
    } 

    public void naveAbatida(NaveEspacialGenerica nave, List<InimigoGenerico> inimigos){

        this.nave = nave;
        retangulo_nave = new Rectangle(nave.getX(), nave.getY(), nave.getLargura() - this.ajuste_colisao, nave.getAltura() - this.ajuste_colisao);

        for(int j=0;j<inimigos.size();j++){
        retangulo_inimigo = new Rectangle(inimigos.get(j).getX(), inimigos.get(j).getY(), inimigos.get(j).getLargura() - this.ajuste_colisao, inimigos.get(j).getAltura() - this.ajuste_colisao);

            if (retangulo_nave.intersects(retangulo_inimigo)) {
                nave.setAbatida(true);                
                this.nave_destruida_audio = true;
                this.nave_destruida_grafico = true;

            }
        }                                                             
    }    

    public void erraTiro(List<TiroGenerico> tiros){
                
        for(int i=0;i<tiros.size();i++){
            if(!tiros.get(i).getVisivel()){
                tiros.remove(i);
            }                                                              
        }          
    } 

    
    public void tocaAudio(){
        /* ------------------- Inimigo destruído -------------------*/
        if(this.inimigo_destruido){
            ref_chipSom.tocaInimigoDestruido();
        }
        /* ------------------- Nave destruída -------------------*/
        if(this.nave_destruida_audio){
            ref_chipSom.tocaNaveDestruida();
        }        
        //Libera gatilhos
        this.nave_destruida_audio = false;
        this.inimigo_destruido = false;    
    }
    
    public void desenha(){
        /* ------------------- Nave destruída -------------------*/
        if(this.nave_destruida_grafico){
            ref_chipGrafico.desenhaNaveEspacialDestruida(nave.getX()-ref_chipGrafico.getLargura_raptor()/7, nave.getY()-ref_chipGrafico.getAltura_raptor()/2);
        }  
        //Libera gatilhos
        this.nave_destruida_grafico = false;
    }
}
