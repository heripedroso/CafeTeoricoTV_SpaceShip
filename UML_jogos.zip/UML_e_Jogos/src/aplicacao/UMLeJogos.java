/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplicacao;
import console.SuperNintendo;
import jogos.spaceship.Jogo;
import console.controles.ControleTecladoDireito;
import console.controles.ControleGenerico;
import jogos.spaceship.Cartucho;
import jogos.spaceship.SomImagem.ChipGrafico;
import jogos.spaceship.SomImagem.ChipSom;
import jogos.spaceship.nave.NaveEspacialGenerica;
import jogos.spaceship.nave.NaveEspacialRaptor;

/**
 *
 * @author Heriberto
 */
public class UMLeJogos{
    
    public UMLeJogos() throws Exception{

        // --------------------------------------- //     
        ControleGenerico controle = new ControleTecladoDireito();
        
        SuperNintendo snes = new SuperNintendo();     

        Cartucho cartucho = new Cartucho();        
        
        snes.conectaControle(controle);   
        
        snes.conectaJogo(cartucho.getJogo());
            
        snes.ligaConsole();  
        
        // --------------------------------------- //
        System.out.println("Jogo conectado: "+snes.jogoConectado());
        System.out.println("Controle conectado: "+snes.controleConectado());
    }
    
    public static void main(String []args) throws Exception{
        new UMLeJogos();        
    }
}

