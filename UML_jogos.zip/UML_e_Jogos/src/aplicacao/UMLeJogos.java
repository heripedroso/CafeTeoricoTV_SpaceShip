/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplicacao;
import console.SuperNintendo;
import console.controles.ControleTecladoDireito;
import console.controles.ControleGenerico;
import jogos.spaceship.Cartucho;

/**
 *
 * @author Heriberto
 */
public class UMLeJogos{
    
    public UMLeJogos() throws Exception{

        // --------------------------------------- //     
        ControleGenerico controle = new ControleTecladoDireito();
                    
        Cartucho cartucho = new Cartucho();                
        
        SuperNintendo snes = new SuperNintendo(controle,cartucho.getJogo()); 
            
    }
    
    public static void main(String []args) throws Exception{

        new UMLeJogos();       
    }
}

